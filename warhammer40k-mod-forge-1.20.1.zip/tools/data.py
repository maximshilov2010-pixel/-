# Warhammer 40,000 (11th edition datasheets, wahapedia.ru, Nov 2026). Stats: M/T/Sv/W/Ld/OC/Inv.
# Weapon DSL: name@range@A@skill@S@AP@D@abilities  (";;" separated).  Footprint (W,D,H) in blocks = base size / 25.4mm.
import re

def slug(s):
    s = s.lower().replace("'", "").replace("’", "")
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")

def U(fac, name, role, pts, comp, base, stats, kw, abil, weapons, dims, cls, **params):
    ws = []
    for w in weapons.split(";;"):
        w = w.strip()
        if not w:
            continue
        n, rng, a, sk, s, ap, d, ab = [x.strip() for x in w.split("@")]
        ws.append(dict(name=n, rng=rng, A=a, skill=sk, S=s, AP=ap, D=d, abil=ab))
    m, t, sv, wd, ld, oc, inv = stats.split("/")
    return dict(id=f"{fac}_{slug(name)}", fac=fac, name=name, role=role, pts=pts, comp=comp, base=base,
                stats=dict(M=m, T=t, Sv=sv, W=wd, Ld=ld, OC=oc, Inv=inv), kw=kw, abil=abil, weapons=ws,
                dims=dims, cls=cls, params=params)

GB = "Gauss blaster@24\"@2@3+@5@-1@1@Lethal Hits"
N = "necrons"
NECRONS = [
 # ---- Battleline / infantry ----
 U(N,"Necron Warriors","Battleline","10 мод. — 85; 20 мод. — 190","10–20 моделей","⌀32 мм",'5"/4/4+/1/7+/2/-',"INFANTRY, BATTLELINE","Their Number is Legion",
   'Gauss flayer@24"@1@4+@4@0@1@Lethal Hits, Rapid Fire 1;;Gauss reaper@12"@2@4+@4@-1@1@Lethal Hits;;Close combat weapon@Melee@1@4+@4@0@1@—',(1,1,1),"humanoid",weapon="gauss",tint=0),
 U(N,"Immortals","Battleline","5 мод. — 65; 10 мод. — 130","5–10 моделей","⌀32 мм",'5"/5/3+/1/7+/2/-',"INFANTRY, BATTLELINE","Implacable Eradication",
   GB+';;Tesla carbine@24"@2@3+@5@0@1@Assault, Sustained Hits 2;;Close combat weapon@Melee@2@3+@4@0@1@—',(1,1,1),"humanoid",weapon="gauss",tint=1),
 U(N,"Lychguard","Infantry (Bodyguard)","5 мод. — 80; 10 мод. — 160","5–10 моделей","⌀32 мм",'5"/5/3+/2/7+/1/-',"INFANTRY, LYCHGUARD","Guardian Protocols; Dispersion Shield (4+ inv)",
   'Hyperphase sword@Melee@3@3+@6@-2@1@—;;Warscythe@Melee@2@3+@8@-3@2@Devastating Wounds',(1,1,1),"humanoid",weapon="scythe",shield=True),
 U(N,"Deathmarks","Infantry (Deep Strike)","5 мод. — 60; 10 мод. — 120","5–10 моделей","⌀32 мм",'5"/5/3+/1/7+/1/-',"INFANTRY, DEATHMARKS","Deep Strike; Hyperspace Hunters",
   'Synaptic disintegrator@36"@1@3+@5@-2@2@Heavy, Precision;;Close combat weapon@Melee@2@3+@4@0@1@—',(1,1,1),"humanoid",weapon="sniper"),
 U(N,"Flayed Ones","Infantry","5 мод. — 55; 10 мод. — 100","5–10 моделей","⌀28,5 мм",'5"/4/4+/1/7+/1/-',"INFANTRY, FLAYED ONES","Infiltrators; Stealth; Flesh Hunger",
   'Flayer claws@Melee@4@3+@4@-1@1@Sustained Hits 1, Twin-linked',(1,1,1),"humanoid",weapon="claws"),
 U(N,"Triarch Praetorians","Infantry (Deep Strike)","5 мод. — 80; 10 мод. — 160","5–10 моделей","⌀32 мм",'10"/5/3+/2/7+/1/-',"INFANTRY, FLY, TRIARCH, PRAETORIANS","Deep Strike; Relentless Combatants",
   'Particle caster@12"@3@3+@5@0@1@Devastating Wounds, Pistol;;Rod of covenant@12"@1@3+@5@-2@2@—;;Rod of covenant@Melee@3@3+@5@-2@2@—;;Voidblade@Melee@4@3+@5@-2@1@—',(1,1,1),"humanoid",weapon="rod",fly=True),
 U(N,"Cryptothralls","Infantry (Retinue)","2 мод. — 60","2 модели","⌀32 мм",'5"/4/3+/3/8+/1/-',"INFANTRY, CRYPTOTHRALLS","Bound Creation; Systematic Vigour",
   'Scouring eye@6"@2@4+@5@-1@1@—;;Scythed limbs@Melee@4@4+@5@-1@1@—',(1,1,1),"humanoid",weapon="claws",bulky=True),
 U(N,"Skorpekh Destroyers","Infantry","3 мод. — 85; 6 мод. — 170","3–6 моделей","⌀50 мм",'8"/6/3+/3/7+/2/-',"INFANTRY, DESTROYER CULT, SKORPEKH DESTROYERS","Whirling Onslaught; Plasmacyte",
   'Skorpekh hyperphase weapons@Melee@4@3+@7@-2@2@—',(2,2,2),"humanoid",weapon="claws",scale=1.7,destroyer=True),
 U(N,"Ophydian Destroyers","Infantry (Deep Strike)","3 мод. — 80; 6 мод. — 150","3–6 моделей","⌀50 мм",'10"/5/4+/3/7+/2/-',"INFANTRY, DESTROYER CULT, OPHYDIAN DESTROYERS","Deep Strike; Tunnelling Horrors; Plasmacyte",
   'Ophydian hyperphase weapons@Melee@5@3+@4@-2@2@—',(2,2,2),"serpent"),
 # ---- Characters ----
 U(N,"Overlord","Character","90","1 модель","⌀40 мм",'5"/5/2+/6/6+/1/4+',"INFANTRY, CHARACTER, NOBLE, OVERLORD","Leader; My Will Be Done; Implacable Resilience; Resurrection Orb",
   'Staff of light@18"@3@2+@5@-2@1@—;;Tachyon arrow@72"@1@2+@16@-5@D6+2@One Shot;;Overlord\'s blade@Melee@4@2+@8@-3@2@Devastating Wounds;;Staff of light@Melee@4@2+@5@-2@1@—;;Voidscythe@Melee@3@3+@12@-3@3@Devastating Wounds',(1,1,1),"humanoid",weapon="blade",cape=True,crown=True),
 U(N,"Overlord with Translocation Shroud","Character","90","1 модель","⌀40 мм",'5"/5/2+/6/6+/1/4+',"INFANTRY, CHARACTER, NOBLE, OVERLORD","Leader; My Will Be Done; Translocation Shroud; Resurrection Orb",
   'Overlord\'s blade@Melee@4@2+@8@-3@2@Devastating Wounds',(1,1,1),"humanoid",weapon="blade",cape=True,crown=True,tint=2),
 U(N,"Lord","Character","65","1 модель","⌀32 мм",'5"/5/3+/4/6+/1/4+',"INFANTRY, CHARACTER, NOBLE, LORD","Leader; Relentless March; The Lord's Will; Resurrection Orb",
   'Staff of light@18"@3@3+@5@-2@1@—;;Staff of light@Melee@3@3+@5@-2@1@—;;Lord\'s blade@Melee@3@3+@8@-3@2@Devastating Wounds',(1,1,1),"humanoid",weapon="blade",cape=True),
 U(N,"Royal Warden","Character","50","1 модель","⌀32 мм",'5"/5/3+/4/6+/1/4+',"INFANTRY, CHARACTER, ROYAL WARDEN","Leader; Adaptive Strategy; Engrammatic Logic",
   'Relic gauss blaster@24"@2@3+@5@-1@2@Lethal Hits, Rapid Fire 2;;Close combat weapon@Melee@4@3+@5@0@1@—',(1,1,1),"humanoid",weapon="gauss",crown=True),
 U(N,"Chronomancer","Character (Cryptek)","70 / 80","1 модель","⌀40 мм",'5"/4/4+/4/6+/1/4+',"INFANTRY, CHARACTER, CRYPTEK, CHRONOMANCER","Support; Timesplinter Mantle; Chronometron",
   'Aeonstave blast@18"@D6@4+@5@-1@1@—;;Aeonstave@Melee@3@4+@5@-1@1@—',(1,1,1),"humanoid",weapon="staff",cape=True),
 U(N,"Technomancer","Character (Cryptek)","80 / 90","1 модель","⌀50 мм",'10"/4/4+/4/6+/1/-',"INFANTRY, CHARACTER, CRYPTEK, FLY, TECHNOMANCER","Support; Rites of Reanimation; Technomancer",
   'Staff of light@18"@3@4+@5@-2@1@—;;Staff of light@Melee@2@4+@5@-2@1@—',(2,2,2),"humanoid",weapon="staff",fly=True,scale=1.5),
 U(N,"Plasmancer","Character (Cryptek)","60","1 модель","⌀32 мм",'5"/4/4+/4/6+/1/-',"INFANTRY, CHARACTER, CRYPTEK, PLASMANCER","Support; Harbinger of Destruction; Living Lightning",
   'Plasmic lance@18"@3@4+@7@-3@2@—;;Plasmic lance@Melee@2@4+@7@-3@2@—',(1,1,1),"humanoid",weapon="staff",cape=True,tint=3),
 U(N,"Psychomancer","Character (Cryptek)","65","1 модель","⌀40 мм",'5"/4/4+/4/6+/1/-',"INFANTRY, CHARACTER, CRYPTEK, PSYCHOMANCER","Support; Nightmare Shroud; Harbinger of Despair",
   'Abyssal lance@18"@1@4+@6@-3@3@—;;Abyssal lance@Melee@1@4+@6@-3@3@—',(1,1,1),"humanoid",weapon="staff",cape=True,tint=4),
 U(N,"Skorpekh Lord","Character","95 / 105","1 модель","⌀60 мм",'8"/7/3+/7/6+/2/4+',"INFANTRY, CHARACTER, DESTROYER CULT, SKORPEKH LORD","Leader; United in Destruction; Crimson Harvest",
   'Enmitic annihilator@18"@2@2+@6@-1@1@Rapid Fire 2;;Flensing claw@Melee@8@2+@6@-1@1@—;;Hyperphase harvester@Melee@4@2+@10@-3@3@—',(2,2,2),"humanoid",weapon="claws",scale=1.9,destroyer=True,crown=True),
 U(N,"Hexmark Destroyer","Character","75","1 модель","⌀50 мм",'8"/5/3+/5/6+/1/-',"INFANTRY, CHARACTER, DESTROYER CULT, HEXMARK DESTROYER","Deep Strike; Lone Operative; Inescapable Death; Multi-threat Eliminator",
   'Enmitic disintegrator pistols@18"@6@2+@6@-2@1@Pistol, Ignores Cover;;Close combat weapon@Melee@4@3+@5@0@1@—',(2,2,2),"humanoid",weapon="pistols",scale=1.6,destroyer=True),
 U(N,"Imotekh the Stormlord","Epic Hero","100","1 модель","⌀40 мм",'5"/5/2+/6/6+/1/4+',"INFANTRY, CHARACTER, EPIC HERO, NOBLE, IMOTEKH THE STORMLORD","Leader; Grand Strategist; Lord of the Storm",
   'Gauntlet of Fire@12"@D6@—@5@-1@1@Ignores Cover, Torrent;;Staff of the Destroyer@18"@3@2+@6@-3@2@—;;Staff of the Destroyer@Melee@4@2+@6@-3@2@Devastating Wounds',(1,1,1),"humanoid",weapon="staff",cape=True,crown=True,tint=5),
 U(N,"Trazyn the Infinite","Epic Hero","60","1 модель","⌀25 мм",'5"/5/2+/6/6+/1/4+',"INFANTRY, CHARACTER, EPIC HERO, NOBLE, TRAZYN THE INFINITE","Leader; Ancient Collector; Surrogate Hosts",
   'Empathic Obliterator@Melee@4@2+@7@0@D3@Sustained Hits D3',(1,1,1),"humanoid",weapon="staff",cape=True,tint=6),
 U(N,"Lokhust Lord","Character (Mounted)","80","1 модель","⌀60 мм (летающая)",'8"/6/3+/5/6+/2/4+',"MOUNTED, CHARACTER, FLY, DESTROYER CULT, LOKHUST LORD","Leader; Destroyer Cult; Driven by Hatred; Nanoscarab Amulet; Resurrection Orb",
   'Staff of light@18"@3@2+@5@-2@1@—;;Lord\'s blade@Melee@4@2+@8@-3@2@Devastating Wounds;;Staff of light@Melee@4@2+@5@-2@1@—',(2,2,2),"lokhust",heavy=False,lord=True),
 U(N,"Catacomb Command Barge","Vehicle Character","120","1 модель","⌀60 мм (летающая)",'10"/8/3+/9/6+/3/4+',"VEHICLE, CHARACTER, NOBLE, FLY, FRAME, CATACOMB COMMAND BARGE","Deadly Demise 1; Carrier Wave (Aura); Advanced Quantum Shielding; Resurrection Orb",
   'Gauss cannon@24"@3@3+@5@-2@2@Lethal Hits;;Staff of light@18"@3@2+@5@-2@1@—;;Tesla cannon@24"@4@3+@6@0@1@Sustained Hits 2;;Overlord\'s blade@Melee@4@2+@8@-3@2@Devastating Wounds;;Staff of light@Melee@4@3+@5@-2@1@—',(2,2,2),"barge",lord=True),
 U(N,"The Silent King","Epic Hero (Vehicle)","420 (3 модели)","Szarekh + 2 Triarchal Menhirs","Szarekh ⌀100 мм; Menhirs ⌀50 мм",'8"/10/2+/16/6+/6/4+',"VEHICLE, EPIC HERO, TRIARCH; Szarekh: CHARACTER, THE SILENT KING","Deadly Demise D6+3 (Szarekh); Triarch Abilities; The Silent King; Supreme Commander; Triarchal Menhirs; Relentless March (Aura)",
   'Sceptre of Eternal Glory@24"@2@2+@10@-3@3@Devastating Wounds;;Staff of Stars@24"@12@2+@6@-1@1@Indirect Fire;;Annihilator beam (Menhir)@24"@1@2+@14@-4@6@—;;Weapons of the Final Triarch@Melee@12@2+@8@-3@2@Lethal Hits;;Armoured bulk (Menhir)@Melee@1@4+@4@0@1@—',(4,4,5),"ctan",kind="king"),
 U(N,"Triarchal Menhir","Epic Hero (часть Silent King)","в составе Silent King","2 модели в комплекте","⌀50 мм",'8"/10/2+/16/6+/6/4+',"VEHICLE, EPIC HERO, TRIARCH","Triarchal Menhirs",
   'Annihilator beam (Menhir)@24"@1@2+@14@-4@6@—;;Armoured bulk (Menhir)@Melee@1@4+@4@0@1@—',(2,2,3),"pylon_small"),
 U(N,"C'tan Shard of the Nightbringer","Epic Hero (Monster)","360","1 модель","⌀90 мм",'10"/11/3+/16/6+/4/4+',"MONSTER, CHARACTER, EPIC HERO, FLY, C'TAN SHARD OF THE NIGHTBRINGER","Deadly Demise D6; Deep Strike; Feel No Pain 5+; Drain Life; Necrodermis",
   'Gaze of Death@18"@D3@2+@12@-3@D6+3@—;;Scythe — strike@Melee@6@2+@14@-4@D6+2@Devastating Wounds;;Scythe — sweep@Melee@14@2+@8@-2@2@—',(4,4,5),"ctan",kind="nightbringer"),
 U(N,"C'tan Shard of the Deceiver","Epic Hero (Monster)","330","1 модель","⌀40 мм",'8"/11/3+/16/6+/4/4+',"MONSTER, CHARACTER, EPIC HERO, FLY, C'TAN SHARD OF THE DECEIVER","Deadly Demise D6; Deep Strike; Feel No Pain 5+; Stealth; Grand Illusion; Necrodermis",
   'Cosmic insanity@18"@6@2+@6@-2@2@Anti-character, Devastating Wounds, Precision;;Golden fists@Melee@8@2+@10@-3@3@—',(2,2,4),"ctan",kind="deceiver"),
 U(N,"C'tan Shard of the Void Dragon","Epic Hero (Monster)","345","1 модель","⌀80 мм",'10"/11/3+/16/6+/4/4+',"MONSTER, CHARACTER, EPIC HERO, FLY, C'TAN SHARD OF THE VOID DRAGON","Deadly Demise D6; Deep Strike; Feel No Pain 5+; Matter Absorption; Necrodermis",
   'Spear of the Void Dragon@12"@D3@2+@8@-3@D6+2@Anti-vehicle;;Voltaic storm blast@18"@D6+3@2+@7@-1@2@Sustained Hits 2;;Spear — strike@Melee@5@2+@12@-4@D6+2@Anti-vehicle;;Spear — sweep@Melee@10@2+@8@-1@2@—;;Canoptek tail blades@Melee@6@2+@6@-1@1@Extra Attacks',(3,3,5),"ctan",kind="voiddragon"),
 U(N,"Transcendent C'tan","Character (Monster)","340 / 360","1 модель","⌀60 мм (летающая)",'8"/11/3+/16/6+/4/4+',"MONSTER, CHARACTER, FLY, TRANSCENDENT C'TAN","Deadly Demise D6; Deep Strike; Feel No Pain 5+; Transdimensional Displacement; Necrodermis",
   'Seismic assault@12"@6@2+@8@-2@2@Assault, Sustained Hits 1;;Crackling tendrils@Melee@8@2+@10@-3@D6@Sustained Hits 1',(2,2,4),"ctan",kind="transcendent"),
 # ---- Canoptek / Beasts / Mounted ----
 U(N,"Canoptek Scarab Swarms","Swarm","3 мод. — 40; 6 мод. — 80","3–6 моделей","⌀40 мм",'10"/2/6+/4/8+/0/-',"SWARM, FLY, CANOPTEK, SCARAB SWARMS","Self-destruction; Chittering Swarm",
   'Feeder mandibles@Melee@6@5+@2@0@1@Lethal Hits',(2,2,1),"swarm"),
 U(N,"Canoptek Macrocytes","Beast (Scout)","5 мод. — 70","5 моделей","⌀28,5 мм",'8"/3/4+/1/8+/1/-',"BEASTS, FLY, CANOPTEK, MACROCYTES","Scouts 8\"; Harassment Swarm (Aura); Accelerator Mandible; Nanoscarab Projector",
   'Atomiser beam@12"@1@4+@6@-1@1@—;;Gauss scalpel@18"@1@4+@4@-1@1@Lethal Hits;;Tesla caster@18"@1@4+@5@0@1@Assault, Sustained Hits 1;;Claws@Melee@2@4+@4@-1@1@—',(1,1,1),"drone"),
 U(N,"Canoptek Tomb Crawlers","Beast","2 мод. — 60","2 модели","⌀50 мм",'5"/4/3+/3/8+/1/-',"BEASTS, CANOPTEK, TOMB CRAWLERS","Weapon Sentinels",
   'Transdimensional isolator@12"@2@4+@4@-2@2@—;;Twin gauss reaper@12"@2@4+@4@-1@1@Twin-linked, Lethal Hits;;Claws@Melee@4@4+@6@-1@1@—',(2,2,2),"crawler"),
 U(N,"Canoptek Wraiths","Beast","3 мод. — 95 / 115; 6 мод. — 220 / 240","3–6 моделей","⌀50 мм",'10"/6/3+/4/8+/2/4+',"BEASTS, FLY, CANOPTEK, WRAITHS","Wraith Form",
   'Particle caster@12"@3@4+@5@0@1@Devastating Wounds, Pistol;;Transdimensional beamer@12"@1@4+@4@-2@3@—;;Vicious claws@Melee@4@4+@6@-1@2@—;;Whip coils@Melee@8@4+@5@0@1@—',(2,2,2),"serpent",wraith=True),
 U(N,"Canoptek Acanthrites","Beast","3 мод. — 85; 6 мод. — 170","3–6 моделей","⌀40 мм",'12"/5/3+/2/8+/2/-',"BEASTS, FLY, CANOPTEK, ACANTHRITES","Infiltrators; Damaged Armour",
   'Cutting beam@12"@1@4+@9@-4@D6@Melta 2;;Voidblade@Melee@3@4+@5@-2@1@—',(2,2,2),"crawler",acan=True),
 U(N,"Canoptek Spyders","Vehicle","1 мод. — 65; 2 мод. — 110","1–2 модели","⌀60 мм (летающая)",'5"/7/3+/6/8+/2/-',"VEHICLE, FLY, CANOPTEK, SPYDERS","Deadly Demise 1; Gloom Prism (Aura); Canoptek Swarm; Fabricator Claw Array (данные неполные)",
   'Particle beamer@18"@D6@3+@6@0@1@Blast, Devastating Wounds;;Automaton claws@Melee@5@4+@8@-2@2@—',(2,2,2),"crawler",spyder=True),
 U(N,"Canoptek Reanimator","Vehicle","75","1 модель","⌀60 мм",'8"/6/3+/6/8+/3/-',"VEHICLE, WALKER, CANOPTEK, REANIMATOR","Feel No Pain 4+; Nanoscarab Reanimation Beam (Aura)",
   'Atomiser beam@12"@3@4+@6@-2@1@—;;Reanimator\'s claws@Melee@4@4+@5@0@1@—',(2,2,3),"crawler",reanim=True),
 U(N,"Canoptek Doomstalker","Vehicle","130","1 модель","⌀90 мм",'8"/8/3+/12/8+/4/4+',"VEHICLE, WALKER, CANOPTEK, DOOMSTALKER","Deadly Demise D3; Sentinel Construct",
   'Doomsday blaster@48"@D6+1@4+@14@-3@3@Blast, Heavy;;Twin gauss flayer@24"@1@4+@4@0@1@Lethal Hits, Rapid Fire 1, Twin-linked;;Doomstalker limbs@Melee@3@4+@6@0@1@—',(4,4,4),"walker_big",gun=True),
 U(N,"Canoptek Tomb Stalker","Monster","130","1 модель","⌀120×92 мм",'10"/9/3+/9/8+/3/4+',"MONSTER, CANOPTEK, TOMB STALKER","Deep Strike; Snaking Ambush; Gloom Prism (Aura)",
   'Gauss slicers@24"@8@4+@5@-1@1@Lethal Hits;;Tomb Stalker claws@Melee@6@4+@6@-1@2@Sustained Hits 1',(5,4,4),"walker_big",scorpion=True),
 U(N,"Canoptek Tomb Sentinel","Monster","115","1 модель","⌀120×92 мм",'10"/9/3+/9/8+/3/4+',"MONSTER, CANOPTEK, TOMB SENTINEL","Deep Strike; Aggressor Guardian; Gloom Prism (Aura)",
   'Exile cannon@18"@D6+1@4+@10@-2@2@—;;Tomb Sentinel claws@Melee@6@4+@6@0@1@—',(5,4,4),"walker_big",scorpion=True,cannon=True),
 U(N,"Triarch Stalker","Vehicle","1–2 — 110; 3+ — 120","1 модель","по модели",'8"/8/3+/12/7+/4/4+',"VEHICLE, WALKER, TRIARCH, FRAME, STALKER","Deadly Demise D3; Scouts 8\"; Targeting Relay",
   'Heat ray — dispersed@12"@2D6@—@5@-1@1@Ignores Cover, Torrent;;Heat ray — focused@18"@2@3+@9@-4@D6@Melta 4;;Particle shredder@18"@D6+6@2+@7@0@1@Blast, Devastating Wounds;;Heavy gauss cannon array@24"@6@3+@8@-2@2@Lethal Hits;;Stalker\'s forelimbs@Melee@4@3+@7@-1@3@—',(4,4,4),"walker_big",gun=True,triarch=True),
 U(N,"Lokhust Destroyers","Mounted","1 мод. — 40/70; 2 — 55/85; 3 — 80/110; 6 — 190/220","1–6 моделей","⌀60 мм (летающая)",'8"/6/3+/3/7+/2/-',"MOUNTED, FLY, DESTROYER CULT, LOKHUST DESTROYERS","Hard-wired for Destruction",
   'Gauss cannon@24"@3@3+@5@-2@2@Lethal Hits;;Close combat weapon@Melee@2@3+@4@0@1@—',(2,2,2),"lokhust"),
 U(N,"Lokhust Heavy Destroyers","Mounted","1 мод. — 50/60; 2 — 100/110; 3 — 165/175","1–3 модели","⌀60 мм (летающая)",'8"/6/3+/4/7+/2/-',"MOUNTED, FLY, DESTROYER CULT, LOKHUST HEAVY DESTROYERS","Optimised for Slaughter",
   'Enmitic exterminator@36"@6@3+@6@-1@1@Heavy, Rapid Fire 6, Sustained Hits 1;;Gauss destructor@48"@1@3+@14@-4@6@Heavy, Lethal Hits;;Close combat weapon@Melee@2@3+@4@0@1@—',(2,2,2),"lokhust",heavy=True),
 U(N,"Tomb Blades","Mounted (Scout)","3 мод. — 70/80; 6 — 140/150","3–6 моделей","⌀32 мм (летающая)",'12"/5/4+/2/7+/2/-',"MOUNTED, FLY, TOMB BLADES","Scouts 9\"; Evasion Engrams",
   'Particle beamer@18"@D6@3+@5@0@1@Blast, Devastating Wounds;;Twin gauss blaster@24"@2@3+@5@-1@1@Twin-linked, Lethal Hits;;Twin tesla carbine@24"@2@3+@5@0@1@Assault, Sustained Hits 2, Twin-linked;;Close combat weapon@Melee@1@4+@4@0@1@—',(1,1,1),"blade"),
 # ---- Vehicles ----
 U(N,"Ghost Ark","Dedicated Transport","100","1 модель","⌀60 мм (летающая)",'10"/9/3+/14/7+/3/4+',"VEHICLE, FLY, FRAME, TRANSPORT, DEDICATED TRANSPORT, GHOST ARK","Deadly Demise D3; Repair Barge; Transport (10 Necron Warriors + 1 Character)",
   'Gauss flayer array (x2)@24"@5@3+@4@0@1@Lethal Hits, Rapid Fire 5;;Armoured bulk@Melee@3@4+@6@0@1@—',(2,3,2),"ark",kind="ghost"),
 U(N,"Doomsday Ark","Vehicle","1–2 — 200; 3+ — 230","1 модель","⌀60 мм (летающая)",'10"/9/3+/14/7+/5/4+',"VEHICLE, FLY, FRAME, DOOMSDAY ARK","Deadly Demise D3; Overwhelming Obliteration",
   'Doomsday cannon@72"@D6+1@3+@18@-4@4@Blast, Heavy;;Gauss flayer array@24"@5@3+@4@0@1@Lethal Hits, Rapid Fire 5;;Armoured bulk@Melee@3@4+@6@0@1@—',(2,3,2),"ark",kind="doomsday"),
 U(N,"Tesseract Ark","Vehicle","130","1 модель","⌀60 мм (летающая)",'9"/9/3+/10/6+/3/4+',"VEHICLE, FLY, TESSERACT ARK","Deadly Demise 1; Gravitational Field",
   'Gauss cannon@24"@3@3+@5@-2@2@Lethal Hits;;Particle beamer@18"@D6@3+@6@0@1@Devastating Wounds;;Tesla cannon@24"@4@3+@6@0@1@Sustained Hits 2;;Particle hurricane@12"@D6+3@—@6@-1@2@Ignores Cover, Torrent;;Seismic lash@36"@D3@3+@9@-3@D6+1@—;;Armoured bulk@Melee@3@4+@6@0@1@—',(2,3,2),"ark",kind="tesseract"),
 U(N,"Annihilation Barge","Vehicle","100","1 модель","⌀60 мм (летающая)",'10"/8/3+/9/7+/3/4+',"VEHICLE, FLY, FRAME, ANNIHILATION BARGE","Deadly Demise 1; Malevolent Arcing",
   'Gauss cannon@24"@3@3+@5@-2@2@Lethal Hits;;Tesla cannon@24"@4@3+@6@0@1@Sustained Hits 2;;Twin tesla destructor@36"@6@3+@8@0@2@Twin-linked, Sustained Hits 2;;Armoured bulk@Melee@3@4+@6@0@1@—',(2,2,2),"barge"),
 U(N,"Doom Scythe","Aircraft","200","1 модель","⌀120×92 мм (летающая)",'—/9/3+/12/7+/—/-',"VEHICLE, AIRCRAFT, FLY, DOOM SCYTHE","Deadly Demise D3; Atavistic Instigation",
   'Heavy death ray@36"@3@3+@16@-4@D6+1@Sustained Hits D3;;Twin tesla destructor@36"@6@3+@8@0@2@Twin-linked, Sustained Hits 2;;Armoured bulk@Melee@3@4+@6@0@1@—',(5,4,3),"scythe",kind="doom"),
 U(N,"Night Shroud","Aircraft","140","1 модель","⌀120×92 мм (летающая)",'20"/9/3+/14/7+/—/-',"VEHICLE, AIRCRAFT, FLY, NIGHT SHROUD","Deadly Demise D3; Death Sphere Bombardment",
   'Twin tesla destructor@36"@6@3+@8@0@2@Twin-linked, Sustained Hits 2;;Armoured bulk@Melee@3@4+@6@0@1@—',(5,4,3),"scythe",kind="shroud"),
 U(N,"Night Scythe","Transport (Aircraft)","125","1 модель","⌀120×92 мм (летающая)",'14"/9/3+/12/7+/0/-',"VEHICLE, FLY, TRANSPORT, NIGHT SCYTHE","Deadly Demise D3; Deep Strike; Hover; Invasion Beams; Quantum Invader; Transport (1 Necrons Infantry unit)",
   'Twin tesla destructor@36"@6@3+@8@0@2@Twin-linked, Sustained Hits 2;;Armoured bulk@Melee@3@4+@6@0@1@—',(5,4,3),"scythe",kind="night"),
 U(N,"Monolith","Titanic Vehicle","1-й — 420; 2-й+ — 440","1 модель","⌀160 мм",'8"/13/2+/22/7+/8/-',"VEHICLE, TITANIC, FLY, FRAME, TOWERING, MONOLITH","Deadly Demise D6; Deep Strike; Eternity Gate",
   'Death ray@24"@1@3+@12@-4@D6+1@Sustained Hits D3;;Gauss flux arc@24"@3@3+@6@-1@1@Lethal Hits, Rapid Fire 3;;Particle whip@24"@3D6@3+@8@-1@2@Blast, Devastating Wounds;;Portal of exile@Melee@6@2+@8@-2@3@—',(6,6,4),"monolith"),
 U(N,"Obelisk","Titanic Vehicle","1-й — 280; 2-й+ — 310","1 модель","⌀120×92 мм (летающая)",'8"/13/2+/24/7+/8/-',"VEHICLE, TITANIC, FLY, FRAME, TOWERING, OBELISK","Deadly Demise D6; Deep Strike; Gravitic Pulse",
   'Tesla sphere@24"@6@3+@7@0@1@Anti-fly 4+, Sustained Hits 2;;Armoured bulk@Melee@6@4+@8@0@1@—',(5,4,5),"obelisk"),
 U(N,"Tesseract Vault","Titanic Vehicle","1-й — 465; 2-й+ — 505","1 модель","⌀120×92 мм (летающая)",'8"/12/2+/24/7+/8/4+',"VEHICLE, TITANIC, FLY, FRAME, TOWERING, TESSERACT VAULT","Deadly Demise D6+3; Powers of the C'tan",
   'Tesla spheres@24"@6@3+@7@0@1@Sustained Hits 2;;Antimatter Meteor@24"@D6+3@3+@10@-3@3@Blast, Devastating Wounds, Indirect Fire, C\'tan Power;;Cosmic Fire@18"@3D6@—@6@-2@1@Ignores Cover, Devastating Wounds, Torrent, C\'tan Power;;Time\'s Arrow@24"@1@2+@3@-2@6@Anti-character 4+, Devastating Wounds, Precision, C\'tan Power;;Armoured bulk@Melee@6@4+@8@0@1@—',(5,4,4),"vault"),
 U(N,"Seraptek Heavy Construct","Super-heavy Walker","1-й — 540; 2-й+ — 570","1 модель","по модели",'10"/12/3+/24/7+/10/5+',"VEHICLE, WALKER, TITANIC, TOWERING, SERAPTEK HEAVY CONSTRUCT, FRAME","Deadly Demise D6+2; Super-heavy Walker; Terrifying Monstrosity",
   'Singularity generator@36"@2D6@3+@10@-3@4@Blast, Devastating Wounds;;Synaptic obliterator@48"@8@3+@5@-1@2@Sustained Hits 2;;Transdimensional projector@48"@2@3+@24@-4@D6+4@—;;Titanic forelimbs — strike@Melee@6@3+@14@-3@5@—;;Titanic forelimbs — sweep@Melee@12@3+@8@-1@2@—',(7,6,5),"construct"),
 # ---- Fortifications ----
 U(N,"Convergence of Dominion Starstele","Fortification","1 — 60; 2 — 120; 3 — 180","1–3 модели","по модели",'—/9/3+/7/8+/0/-',"FORTIFICATION, FRAME, VEHICLE, CONVERGENCE OF DOMINION","Reanimation Nodes (Aura); Ancient Cover; Fortification",
   'Transdimensional abductor@18"@3@4+@6@-2@3@—',(2,2,4),"pylon_small"),
 U(N,"Sentry Pylon","Fortification","120","1 модель","по модели",'—/8/3+/10/7+/0/-',"FORTIFICATION, VEHICLE, FRAME, SENTRY PYLON","Deadly Demise D3; Teleportation Matrix; Phase-shifted Cover",
   'Gauss exterminator@48"@1@4+@14@-3@6@Lethal Hits;;Focused death ray@36"@6@4+@8@-2@2@Sustained Hits 2;;Heat cannon@36"@2@4+@9@-4@D6@Melta 4',(3,3,5),"pylon"),
 U(N,"Gauss Pylon","Fortification (Titanic)","210","1 модель","по модели",'—/12/3+/22/7+/0/5+',"FORTIFICATION, VEHICLE, TOWERING, TITANIC, GAUSS PYLON","Deadly Demise D6+2; Phase Shift Generator (Aura); Phase-shifted Cover",
   'Gauss annihilator@120"@1@4+@16@-4@D6+6@Anti-fly 2+, Lethal Hits;;Tesla arc@6"@6@4+@4@0@1@Sustained Hits 2',(4,4,5),"pylon",big=True),
 U(N,"Tomb Citadel Walls","Fortification (Titanic)","180","1 модель","по модели",'—/13/2+/50/7+/0/5+',"FORTIFICATION, TITANIC, VEHICLE, FRAME, TOMB CITADEL","Deadly Demise 3D6; Ziggurat Dock; Phased Cover",
   'Gauss exterminator@48"@1@4+@14@-3@6@Lethal Hits;;Twin tesla destructor@36"@6@3+@8@0@2@Sustained Hits 2, Twin-linked',(7,3,3),"walls"),
]

K = "knights"
KS = "Questoris reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—"
KNIGHTS = [
 U(K,"Knight Paladin","Vehicle Character (Questoris)","375 / 390","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT PALADIN","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Paladin's Duty (Bondsman); Seasoned Noble",
   'Ironstorm missile pod@48"@D6+1@3+@5@0@1@Blast, Indirect Fire;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Rapid-fire battle cannon@72"@D6+3@3+@10@-1@3@Blast, Rapid Fire D6+3;;Stormspear rocket pod@48"@3@3+@8@-2@D6@—;;Twin Icarus autocannon@48"@3@3+@7@-1@2@Anti-fly 2+, Twin-linked;;Reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—;;Thunderstrike gauntlet — strike@Melee@4@3+@20@-3@8@—;;Thunderstrike gauntlet — sweep@Melee@8@3+@10@-2@3@—',(7,4,5),"knight",arm_l="chainsword",arm_r="cannon",carapace="pods"),
 U(K,"Knight Errant","Vehicle Character (Questoris)","355 / 370","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT ERRANT","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Errant's Duty (Bondsman); Aggressive Assault",
   'Ironstorm missile pod@48"@D6+1@3+@5@0@1@Blast, Indirect Fire;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Stormspear rocket pod@48"@3@3+@8@-2@D6@—;;Thermal cannon@24"@2D3@3+@12@-4@D6@Blast, Melta 6;;Twin Icarus autocannon@48"@3@3+@7@-1@2@Anti-fly 2+, Twin-linked;;Reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—;;Thunderstrike gauntlet — strike@Melee@4@3+@20@-3@8@—;;Thunderstrike gauntlet — sweep@Melee@8@3+@10@-2@3@—',(7,4,5),"knight",arm_l="chainsword",arm_r="thermal",carapace="pods"),
 U(K,"Knight Gallant","Vehicle Character (Questoris)","355 / 370","1 модель","⌀170×109 мм",'12"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT GALLANT","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Gallant's Duty (Bondsman); Martial Pride",
   'Ironstorm missile pod@48"@D6+1@3+@5@0@1@Blast, Indirect Fire;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Stormspear rocket pod@48"@3@3+@8@-2@D6@—;;Twin Icarus autocannon@48"@3@3+@7@-1@2@Anti-fly 2+, Twin-linked;;Reaper chainsword — strike@Melee@6@2+@14@-4@6@Devastating Wounds;;Reaper chainsword — sweep@Melee@18@2+@9@-3@2@Lethal Hits;;Thunderstrike gauntlet — strike@Melee@6@2+@20@-3@8@Devastating Wounds;;Thunderstrike gauntlet — sweep@Melee@12@2+@10@-2@3@Lethal Hits',(7,4,5),"knight",arm_l="chainsword",arm_r="gauntlet",carapace="pods"),
 U(K,"Knight Crusader","Vehicle Character (Questoris)","395 / 415","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT CRUSADER","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Crusader's Duty (Bondsman); Punishing Salvoes",
   'Avenger gatling cannon@36"@18@3+@6@-2@2@—;;Heavy flamer@12"@D6@—@5@-1@1@Ignores Cover, Torrent;;Ironstorm missile pod@48"@D6+1@3+@5@0@1@Blast, Indirect Fire;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Rapid-fire battle cannon@72"@D6+3@3+@10@-1@3@Blast, Rapid Fire D6+3;;Stormspear rocket pod@48"@3@3+@8@-2@D6@—;;Thermal cannon@24"@2D3@3+@12@-4@D6@Blast, Melta 6;;Twin Icarus autocannon@48"@3@3+@7@-1@2@Anti-fly 2+, Twin-linked;;Titanic feet@Melee@4@4+@8@-1@2@—',(7,4,5),"knight",arm_l="gatling",arm_r="thermal",carapace="pods"),
 U(K,"Knight Defender","Vehicle Character (Questoris)","385 / 405","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/4+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT DEFENDER","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Defender's Duty (Bondsman); Selfless Protector",
   'Conversion beam obliterator@36"@3@3+@12@-2@4@Conversion, Sustained Hits D3;;Plasma executor — standard@36"@D6+3@3+@8@-2@2@Blast;;Plasma executor — supercharge@36"@D6+3@3+@9@-3@3@Blast, Hazardous;;Phosphor blaster@24"@1@3+@5@0@1@Ignores Cover, Rapid Fire 1;;Twin incendine combustor@12"@D6@—@6@-1@1@Ignores Cover, Torrent, Twin-linked;;Titanic feet@Melee@4@4+@8@-1@2@—',(7,4,5),"knight",arm_l="shield_gun",arm_r="cannon",carapace="pods"),
 U(K,"Knight Preceptor","Vehicle Character (Questoris)","365 / 380","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT PRECEPTOR","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Mentor (Bondsman); Exemplar of the Code",
   'Ironstorm missile pod@48"@D6+1@3+@5@0@1@Blast, Indirect Fire;;Las-impulsor — high intensity@24"@D6@3+@14@-3@4@Blast;;Las-impulsor — low intensity@36"@2D6@3+@7@-1@2@Blast;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris multi-laser@36"@4@3+@6@0@1@—;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Stormspear rocket pod@48"@3@3+@8@-2@D6@—;;Twin Icarus autocannon@48"@3@3+@7@-1@2@Anti-fly 2+, Twin-linked;;Reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—;;Thunderstrike gauntlet — strike@Melee@4@3+@20@-3@8@—;;Thunderstrike gauntlet — sweep@Melee@8@3+@10@-2@3@—',(7,4,5),"knight",arm_l="chainsword",arm_r="laser",carapace="pods"),
 U(K,"Knight Warden","Vehicle Character (Questoris)","365 / 380","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, IMPERIUM, KNIGHT WARDEN","Deadly Demise D6",
   'Avenger gatling cannon@36"@18@3+@6@-2@2@—;;Heavy flamer@12"@D6@—@5@-1@1@Ignores Cover, Torrent;;Ironstorm missile pod@48"@D6+1@3+@5@0@1@Blast, Indirect Fire;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Stormspear rocket pod@48"@3@3+@8@-2@D6@—;;Twin Icarus autocannon@48"@3@3+@7@-1@2@Anti-fly 2+, Twin-linked;;Reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—;;Thunderstrike gauntlet — strike@Melee@4@3+@20@-3@8@—;;Thunderstrike gauntlet — sweep@Melee@8@3+@10@-2@3@—',(7,4,5),"knight",arm_l="chainsword",arm_r="gatling",carapace="pods"),
 U(K,"Canis Rex","Epic Hero (Vehicle)","415","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, QUESTORIS, CHARACTER, EPIC HERO, IMPERIUM, CANIS REX","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Legendary Freeblade; Chainbreaker",
   'Las-impulsor — high intensity@24"@D6@2+@14@-3@4@Blast, Sustained Hits 1;;Las-impulsor — low intensity@36"@2D6@2+@7@-1@2@Blast, Sustained Hits 1;;Questoris multi-laser@36"@4@2+@6@0@1@Sustained Hits 1;;Freedom\'s Hand — strike@Melee@5@2+@20@-3@9@Sustained Hits 1;;Freedom\'s Hand — sweep@Melee@10@2+@10@-2@3@Sustained Hits 1',(7,4,5),"knight",arm_l="gauntlet",arm_r="laser",carapace="pods",banner=True),
 U(K,"Knight Destrier","Vehicle Character (Bellatus)","265 / 280","1 модель","⌀150×95 мм",'12"/10/3+/18/6+/8/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, BELLATUS, CHARACTER, IMPERIUM, KNIGHT DESTRIER","Deadly Demise D6; Code Chivalric; Super-heavy Walker; Ram Jets; Thundercharge; Saturation Fire",
   'Chastiser gatling cannon@24"@12@3+@6@-1@2@Assault;;Frag bombard@24"@D6+3@3+@7@-1@2@Assault, Blast, Rapid Fire D6+3;;Questoris heavy stubber@36"@6@3+@4@-1@1@Assault, Rapid Fire 3;;Bellatus reaper chainsword — strike@Melee@5@3+@12@-3@D3+3@—;;Bellatus reaper chainsword — sweep@Melee@10@3+@8@-2@2@—;;Thundershock spear — strike@Melee@4@3+@12@-3@D3+3@Lance;;Thundershock spear — sweep@Melee@8@3+@6@-3@2@Lance;;Titanic feet@Melee@4@4+@8@-1@2@—',(6,4,4),"knight",arm_l="chainsword",arm_r="gatling",carapace="none",light=True),
 U(K,"Knight Castellan","Vehicle Character (Dominus)","425 / 450","1 модель","⌀170×109 мм",'8"/12/3+/28/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, DOMINUS, CHARACTER, IMPERIUM, KNIGHT CASTELLAN","Deadly Demise D6+2; Code Chivalric; Super-heavy Walker; Ion Aegis; Titan Hunter",
   'Plasma decimator — standard@48"@D6+3@3+@8@-3@2@Blast;;Plasma decimator — supercharge@48"@D6+3@3+@9@-4@3@Blast, Hazardous;;Shieldbreaker missile launcher@72"@1@3+@12@-6@D6+1@Anti-titanic 4+, Devastating Wounds;;Twin meltagun@12"@1@3+@9@-4@D6@Melta 2, Twin-linked;;Twin siegebreaker cannon@36"@D6@3+@6@0@1@Blast, Twin-linked;;Volcano lance@72"@D3@3+@18@-5@D6+8@Blast;;Titanic feet@Melee@4@4+@8@-1@2@—',(7,4,5),"knight",arm_l="lance",arm_r="decimator",carapace="missiles",dominus=True),
 U(K,"Knight Valiant","Vehicle Character (Dominus)","390 / 405","1 модель","⌀170×109 мм",'8"/12/3+/28/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, DOMINUS, CHARACTER, IMPERIUM, KNIGHT VALIANT","Deadly Demise D6+2; Code Chivalric; Super-heavy Walker; Ion Aegis; Thundershock",
   'Conflagration cannon@18"@3D6@—@8@-1@2@Ignores Cover, Torrent;;Shieldbreaker missile launcher@72"@1@3+@12@-6@D6+1@Anti-titanic 4+, Devastating Wounds;;Thundercoil harpoon@12"@D3@3+@24@-6@10@Blast, Devastating Wounds;;Twin meltagun@12"@1@3+@9@-4@D6@Melta 2, Twin-linked;;Twin siegebreaker cannon@36"@D6@3+@6@0@1@Blast, Twin-linked;;Titanic feet@Melee@4@4+@8@-1@2@—',(7,4,5),"knight",arm_l="harpoon",arm_r="flame",carapace="missiles",dominus=True),
 U(K,"Cerastus Knight Acheron","Vehicle Character (Cerastus)","380 / 395","1 модель","⌀170×109 мм",'12"/11/3+/28/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, CHARACTER, TITANIC, TOWERING, IMPERIUM, CERASTUS, KNIGHT ACHERON","Deadly Demise D6+2",
   'Acheron flame cannon@18"@2D6@—@8@-1@2@Ignores Cover, Torrent;;Twin heavy bolter@36"@3@3+@5@-1@2@Sustained Hits 1, Twin-linked;;Reaper chainfist — strike@Melee@4@3+@14@-4@6@—;;Reaper chainfist — sweep@Melee@12@3+@9@-3@2@—',(7,4,5),"knight",arm_l="chainsword",arm_r="flame",carapace="none",cerastus=True),
 U(K,"Cerastus Knight Atrapos","Vehicle Character (Cerastus)","420 / 440","1 модель","⌀170×109 мм",'12"/11/3+/28/6+/10/5+',"VEHICLE, WALKER, CHARACTER, TITANIC, TOWERING, IMPERIUM, CERASTUS, KNIGHT ATRAPOS","Deadly Demise D6+2",
   'Atrapos lascutter — low intensity@36"@2D6@3+@7@-1@2@Sustained Hits 1;;Atrapos lascutter — high intensity@24"@D6@3+@14@-3@4@Sustained Hits 1;;Graviton singularity cannon — contained@24"@D3@3+@16@-4@D6+1@Blast;;Graviton singularity cannon — singularity@24"@D3@3+@16@-4@D6+1@Blast, Devastating Wounds, Hazardous;;Lascutter (бой) — low intensity@Melee@12@3+@7@-1@2@Sustained Hits 1;;Lascutter (бой) — high intensity@Melee@6@3+@14@-3@4@Sustained Hits 1',(7,4,5),"knight",arm_l="lascutter",arm_r="gravcannon",carapace="none",cerastus=True),
 U(K,"Cerastus Knight Castigator","Vehicle Character (Cerastus)","380 / 395","1 модель","⌀170×109 мм",'12"/11/3+/28/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, CHARACTER, TITANIC, TOWERING, IMPERIUM, CERASTUS, KNIGHT CASTIGATOR","Deadly Demise D6+2",
   'Castigator bolt cannon@36"@18@3+@6@-2@2@Twin-linked;;Tempest warblade — strike@Melee@4@3+@14@-4@6@—;;Tempest warblade — sweep@Melee@12@3+@9@-3@2@—',(7,4,5),"knight",arm_l="chainsword",arm_r="bolt",carapace="none",cerastus=True),
 U(K,"Cerastus Knight Lancer","Vehicle Character (Cerastus)","415 / 435","1 модель","⌀170×109 мм",'14"/11/3+/28/6+/10/4+',"VEHICLE, WALKER, CHARACTER, TITANIC, TOWERING, IMPERIUM, CERASTUS, KNIGHT LANCER","Deadly Demise D6+2",
   'Cerastus shock lance@12"@6@3+@6@0@2@Assault, Sustained Hits 2;;Cerastus shock lance — strike@Melee@5@2+@20@-3@8@Lance;;Cerastus shock lance — sweep@Melee@10@2+@10@-2@3@—',(7,4,5),"knight",arm_l="shocklance",arm_r="shocklance",carapace="none",cerastus=True),
 U(K,"Questoris Knight Magaera","Vehicle Character (Questoris)","385 / 400","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+',"VEHICLE, WALKER, CHARACTER, TITANIC, TOWERING, IMPERIUM, QUESTORIS, KNIGHT MAGAERA","Deadly Demise D6",
   'Lightning cannon@48"@12@3+@9@0@2@Sustained Hits 2;;Phased plasma-fusil@24"@2@3+@8@-3@2@Rapid Fire 2;;Twin rad cleanser@12"@D6@—@2@0@1@Anti-infantry 2+, Ignores Cover, Torrent, Twin-linked;;Hekaton siege claw — strike@Melee@4@3+@20@-3@8@—;;Hekaton siege claw — sweep@Melee@8@3+@10@-2@3@—;;Reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—',(7,4,5),"knight",arm_l="claw",arm_r="laser",carapace="pods",hekaton=True),
 U(K,"Questoris Knight Styrix","Vehicle Character (Questoris)","375 / 390","1 модель","⌀170×109 мм",'10"/11/3+/26/6+/10/5+',"VEHICLE, WALKER, CHARACTER, TITANIC, TOWERING, IMPERIUM, QUESTORIS, KNIGHT STYRIX","Deadly Demise D6",
   'Graviton crusher@18"@3@3+@6@-1@2@Anti-vehicle 2+, Blast;;Twin rad cleanser@12"@D6@—@2@0@1@Anti-infantry 2+, Ignores Cover, Torrent, Twin-linked;;Volkite chierovile@30"@12@3+@12@0@3@Devastating Wounds;;Hekaton siege claw — strike@Melee@4@3+@20@-3@8@—;;Hekaton siege claw — sweep@Melee@8@3+@10@-2@3@—;;Reaper chainsword — strike@Melee@4@3+@14@-4@6@—;;Reaper chainsword — sweep@Melee@12@3+@9@-3@2@—',(7,4,5),"knight",arm_l="claw",arm_r="volkite",carapace="pods",hekaton=True),
 U(K,"Acastus Knight Asterius","Titanic Vehicle (Acastus)","785 / 860","1 модель","по модели",'8"/13/2+/30/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, ACASTUS, IMPERIUM, KNIGHT ASTERIUS, FRAME","Deadly Demise 2D6",
   'Asterius volkite culverin@24"@6@3+@6@0@2@Devastating Wounds;;Karacnos mortar battery@48"@D6+3@3+@6@-1@1@Anti-infantry 2+, Blast, Ignores Cover, Indirect Fire;;Twin conversion beam cannon@48"@3@3+@16@-2@6@Conversion, Sustained Hits D3, Twin-linked;;Titanic feet@Melee@6@4+@10@-1@2@Conversion',(8,5,6),"acastus",twin_beam=True),
 U(K,"Acastus Knight Porphyrion","Titanic Vehicle (Acastus)","725 / 800","1 модель","по модели",'8"/13/2+/30/6+/10/5+ (только дальний бой)',"VEHICLE, WALKER, TITANIC, TOWERING, IMPERIUM, ACASTUS, KNIGHT PORPHYRION, FRAME","Deadly Demise 2D6",
   'Acastus autocannon@48"@2@3+@9@-1@3@—;;Acastus ironstorm missile pod@48"@D6+6@3+@5@0@1@Blast, Heavy, Indirect Fire;;Helios defence missiles@48"@3@3+@10@-2@D6@Anti-fly 2+, Heavy;;Lascannon@48"@1@3+@12@-3@D6+1@—;;Twin magna lascannon@72"@D6@3+@18@-4@D6+6@Blast, Twin-linked;;Titanic feet@Melee@6@4+@10@-1@2@—',(8,5,6),"acastus",twin_beam=False),
 U(K,"Armiger Helverin","Vehicle (Armiger)","140","1 модель","⌀100 мм",'12"/9/3+/14/7+/6/5+ (только дальний бой)',"VEHICLE, WALKER, IMPERIUM, ARMIGER, HELVERIN","Deadly Demise D3",
   'Armiger autocannon@48"@4@3+@9@-1@3@—;;Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Armoured feet@Melee@4@3+@6@0@1@—',(4,4,4),"armiger",arm_r="autocannon",arm_l="autocannon"),
 U(K,"Armiger Warglaive","Vehicle (Armiger)","140","1 модель","⌀100 мм",'12"/9/3+/14/7+/6/5+ (только дальний бой)',"VEHICLE, WALKER, IMPERIUM, ARMIGER, WARGLAIVE","Deadly Demise D3",
   'Meltagun@12"@1@3+@9@-4@D6@Melta 2;;Questoris heavy stubber@36"@3@3+@4@-1@1@Rapid Fire 3;;Thermal spear@18"@2@3+@12@-4@D6@Melta 4;;Reaper chain-cleaver — strike@Melee@4@3+@10@-3@3@—;;Reaper chain-cleaver — sweep@Melee@8@3+@8@-2@1@—',(4,4,4),"armiger",arm_r="chainsword",arm_l="spear"),
 U(K,"Armiger Moirax","Vehicle (Armiger)","150 / 160","1 модель","⌀100 мм",'12"/9/3+/14/7+/6/5+ (только дальний бой)',"VEHICLE, WALKER, IMPERIUM, ARMIGER, MOIRAX","Deadly Demise D3",
   'Conversion beam cannon@24"@1@3+@10@-2@3@Conversion, Sustained Hits D3;;Graviton pulsar@24"@D6@3+@7@-1@2@Anti-vehicle 2+, Blast;;Lightning lock@36"@6@3+@8@0@1@Sustained Hits 2;;Rad cleanser@12"@D6@—@2@0@1@Anti-infantry 2+, Ignores Cover, Torrent;;Volkite veuglaire@36"@4@3+@8@0@2@Devastating Wounds;;Armoured feet@Melee@4@3+@6@0@1@—;;Siege claw@Melee@4@3+@12@-3@D6+2@Conversion',(4,4,4),"armiger",arm_r="claw",arm_l="volkite"),
 U(K,"Skitarii Rangers","Battleline","10 мод. — 85","1 Alpha + 9 Rangers","⌀25 мм",'6"/3/4+/1/7+/2/5+',"INFANTRY, BATTLELINE, IMPERIUM, SKITARII, RANGERS","Scouts 6\"; Objective Scouted; Enhanced data-tether; Omnispex",
   'Mechanicus pistol@12"@1@4+@6@-1@1@Devastating Wounds, Pistol;;Arc rifle@30"@1@4+@8@-1@D3@Anti-vehicle 4+, Devastating Wounds, Rapid Fire 1;;Galvanic rifle@30"@2@4+@4@0@1@—;;Plasma caliver — standard@30"@2@4+@7@-2@1@—;;Plasma caliver — supercharge@30"@2@4+@8@-3@2@Hazardous;;Transuranic arquebus@36"@1@4+@7@-2@D3@Heavy, Precision;;Alpha combat weapon@Melee@2@4+@5@-1@1@—;;Close combat weapon@Melee@1@4+@3@0@1@—',(1,1,1),"skitarii",weapon="rifle"),
 U(K,"Skitarii Vanguard","Battleline","10 мод. — 85","1 Alpha + 9 Vanguard","⌀25 мм",'6"/3/4+/1/7+/2/5+',"INFANTRY, BATTLELINE, IMPERIUM, SKITARII, VANGUARD","Rad-saturation (Aura); Enhanced data-tether; Omnispex",
   'Mechanicus pistol@12"@1@4+@6@-1@1@Devastating Wounds, Pistol;;Arc rifle@30"@1@4+@8@-1@D3@Anti-vehicle 4+, Devastating Wounds, Rapid Fire 1;;Plasma caliver — standard@30"@2@4+@7@-2@1@—;;Plasma caliver — supercharge@30"@2@4+@8@-3@2@Hazardous;;Radium carbine@18"@3@4+@3@0@1@Anti-infantry 4+;;Transuranic arquebus@36"@1@4+@7@-2@D3@Heavy, Precision;;Alpha combat weapon@Melee@2@4+@5@-1@1@—;;Close combat weapon@Melee@1@4+@3@0@1@—',(1,1,1),"skitarii",weapon="carbine"),
 U(K,"Sir Hekhtur","Epic Hero","—","1 модель","⌀25 мм",'6"/3/4+/3/5+/1/-',"INFANTRY, CHARACTER, EPIC HERO, IMPERIUM, SIR HEKHTUR","Lone Operative; Using Sir Hekhtur",
   'Hekhtur\'s pistol@12"@1@2+@5@-1@2@Pistol;;Close combat weapon@Melee@2@2+@3@0@1@—',(1,1,1),"skitarii",weapon="pistol",noble=True),
]
UNITS = NECRONS + KNIGHTS
if __name__ == "__main__":
    ids = [u["id"] for u in UNITS]
    assert len(ids) == len(set(ids)), [i for i in ids if ids.count(i) > 1]
    print(len(NECRONS), len(KNIGHTS))


# --- symmetric footprints: big units get a square base (average of the two sides, rounded up) ---
SYMMETRIC_EXCEPT = {"necrons_tomb_citadel_walls"}  # walls stay long and thin
for _u in UNITS:
    _w, _d, _h = _u["dims"]
    if _w != _d and _w * _d * _h > 1 and _u["id"] not in SYMMETRIC_EXCEPT:
        _s = (_w + _d + 1) // 2
        _u["dims"] = (_s, _s, _h)

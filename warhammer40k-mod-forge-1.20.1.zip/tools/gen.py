"""Generates all assets (models, blockstates, textures, lang, loot) and UnitData.java for the w40k mod."""
import json, math, os, re, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image
import data, models40k, books40k
from names_ru import RU
USE_RU_NAMES = False  # set True for Russian unit names

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
MODID = "warhammer40k"
ASSETS = os.path.join(ROOT, "src/main/resources/assets", MODID)
DATA = os.path.join(ROOT, "src/main/resources/data", MODID)
JAVA = os.path.join(ROOT, "src/main/java/dev/w40k/UnitData.java")

FACTIONS = [  # id, colour, en, ru
    ("necrons", 0x3DDC7A, "Necrons", "Некроны"),
    ("knights", 0x3A63C4, "Imperial Knights", "Имперские Рыцари"),
]
PAL = {
    "necrons": [(255, 255, 255), (140, 140, 140), (0x8c, 0x96, 0xa3), (0x9a, 0xa5, 0xb1), (0x11, 0x14, 0x18), (0xc9, 0xa2, 0x27), (0xe6, 0xe2, 0xd3), (0x3d, 0xf0, 0x7a)],
    "knights": [(255, 255, 255), (140, 140, 140), (0xe0, 0xd6, 0xb5), (0x8d, 0x94, 0x9e), (0x1a, 0x1a, 0x1f), (0xe0, 0xb0, 0x30), (0xf2, 0xf2, 0xf2), (0xc6, 0x28, 0x28)],
}
MARKERS = [  # id, colour, glyph, en, ru
    ("marker_objective", 0xE0A800, "star", "Objective Marker", "Маркер цели"),
    ("marker_battleshock", 0x7E3FBF, "bang", "Battle-shock Marker", "Маркер Battle-shock"),
    ("marker_wounded", 0xC62828, "x", "Wounded Marker", "Маркер ран / потерь"),
    ("marker_activated", 0x8A8F98, "dot", "Activated Marker", "Маркер «уже ходил»"),
]
FULL = {
    "x": ["............", "..##....##..", "...##..##...", "....####....", ".....##.....", "....####....", "...##..##...", "..##....##..", "............", "............", "............", "............"],
    "bang": ["............", ".....##.....", ".....##.....", ".....##.....", ".....##.....", ".....##.....", ".....##.....", "............", ".....##.....", ".....##.....", "............", "............"],
    "dot": ["............", "............", "....####....", "...######...", "...######...", "...######...", "...######...", "....####....", "............", "............", "............", "............"],
    "star": ["............", ".....##.....", ".....##.....", "..########..", "...######...", "....####....", "...##..##...", "..##....##..", "............", "............", "............", "............"],
}
SIZES = {"necrons": 0, "knights": 0}


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def save_json(path, obj):
    write(path, json.dumps(obj, ensure_ascii=False, indent=1) + "\n")


def rgb(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def token_texture(color, key):
    col = rgb(color)
    img = Image.new("RGBA", (16, 16), shade(col, 0.33) + (255,))
    px = img.load()
    for i in range(16):
        for p in ((i, 0), (i, 15), (0, i), (15, i)):
            px[p] = col + (255,)
    for y, row in enumerate(FULL[key]):
        for x, ch in enumerate(row):
            if ch == "#":
                px[x + 2, y + 2] = (240, 232, 210, 255)
    return img


def palette_texture(colors):
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for i, c in enumerate(colors):
        cx, cy = (i % 4) * 4, (i // 4) * 4
        for x in range(4):
            for y in range(4):
                px[cx + x, cy + y] = c + (255,)
    return img


def tool_textures():
    out = {}
    d = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); p = d.load()
    for x in range(2, 14):
        for y in range(2, 14):
            p[x, y] = (232, 232, 232, 255)
    for i in range(2, 14):
        for q in ((i, 2), (i, 13), (2, i), (13, i)):
            p[q] = (50, 50, 50, 255)
    for (x, y) in [(5, 5), (10, 5), (5, 10), (10, 10), (7, 7), (8, 8)]:
        for dx in range(2):
            for dy in range(2):
                p[x + dx, y + dy] = (200, 30, 30, 255)
    out["d6"] = d
    r = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); s = r.load()
    for i in range(1, 15):
        for t in range(5, 11):
            s[i, t] = (230, 200, 90, 255)
        for t in (5, 10):
            s[i, t] = (120, 90, 30, 255)
        if i % 2 == 1:
            s[i, 6] = (60, 40, 20, 255)
            if i % 4 == 1:
                s[i, 7] = (60, 40, 20, 255)
    out["ruler"] = r
    m = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); q = m.load()
    for i in range(3, 13):
        q[i, 8] = (60, 220, 90, 255); q[i, 7] = (60, 220, 90, 255)
    for k in range(6):
        for yy in (8 - k - 1, 7 + k + 1):
            if 0 <= yy < 16:
                q[13 - k, yy] = (60, 220, 90, 255)
    for i in range(2, 6):
        q[i, 9] = (30, 120, 50, 255)
    out["move_tool"] = m
    pr = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); z = pr.load()
    for i in range(3, 13):
        for t in (5, 6, 7, 8, 9):
            z[i, t] = (235, 235, 245, 255)
    for i in range(3, 13):
        z[i, 5] = z[i, 9] = (150, 160, 200, 255)
    for i in range(0, 3):
        z[i, 7] = (180, 120, 60, 255)
    out["paint_remover"] = pr
    a = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); p2 = a.load()
    for yy in range(16):
        for xx in range(16):
            d = math.hypot(xx - 7.5, yy - 7.5)
            if 5.0 <= d <= 6.6 or (abs(xx - 7.5) < 1.0 and d <= 7.5 and d > 2.2) or (abs(yy - 7.5) < 1.0 and d <= 7.5 and d > 2.2):
                p2[xx, yy] = (225, 40, 40, 255)
    p2[7, 7] = p2[8, 8] = p2[7, 8] = p2[8, 7] = (255, 220, 220, 255)
    out["attack_tool"] = a
    return out


def tiles_of(parts, W, D, H):
    """Slice cuboids at 16px boundaries. Returns {part_index: [local cuboids]}."""
    tiles = {}
    for (x1, y1, z1, x2, y2, z2, s) in parts:
        for ty in range(int(y1 // 16), min(H, math.ceil(y2 / 16))):
            for tz in range(int(z1 // 16), min(D, math.ceil(z2 / 16))):
                for tx in range(int(x1 // 16), min(W, math.ceil(x2 / 16))):
                    a = [max(x1, tx * 16), max(y1, ty * 16), max(z1, tz * 16)]
                    c = [min(x2, tx * 16 + 16), min(y2, ty * 16 + 16), min(z2, tz * 16 + 16)]
                    if c[0] - a[0] < 0.04 or c[1] - a[1] < 0.04 or c[2] - a[2] < 0.04:
                        continue
                    idx = (ty * D + tz) * W + tx
                    tiles.setdefault(idx, []).append([a[0] - tx * 16, a[1] - ty * 16, a[2] - tz * 16, c[0] - tx * 16, c[1] - ty * 16, c[2] - tz * 16, s])
    return tiles


def elements(parts, rot=0.0):
    els = []
    for (x1, y1, z1, x2, y2, z2, slot) in parts:
        cx, cy = (slot % 4) * 4, (slot // 4) * 4
        uv = [cx + 1, cy + 1, cx + 3, cy + 3]
        faces = {d: {"texture": "#p", "uv": uv} for d in ("north", "south", "east", "west", "up", "down")}
        if slot in (0, 1):  # main armour colour: tinted by the paint (see ClientColors)
            for f in faces.values():
                f["tintindex"] = 0
        el = {"from": [round(x1, 3), round(y1, 3), round(z1, 3)], "to": [round(x2, 3), round(y2, 3), round(z2, 3)], "faces": faces}
        if rot:
            # element rotation: positive = counter-clockwise from above; blockstate y = clockwise
            el["rotation"] = {"origin": [8, 0, 8], "axis": "y", "angle": -rot}
        els.append(el)
    return els


def tex(fid):
    pal = f"{MODID}:block/pal_{fid}"
    return {"p": pal, "particle": pal}


def emit_unit(u, lang_en, lang_ru):
    uid, fid = u["id"], u["fac"]
    W, D, H = u["dims"]
    parts = models40k.build(u)
    models40k_check(parts, W, D, H)
    if W * D * H == 1:
        for suffix, d in (("", 0), ("_r1", 22.5), ("_r2", 45), ("_r3", -22.5)):
            save_json(os.path.join(ASSETS, "models/block", f"{uid}{suffix}.json"),
                      {"parent": "minecraft:block/block", "textures": tex(fid), "elements": elements(parts, d)})
        variants = {}
        for r in range(16):
            k, rem = divmod(r, 4)
            suffix = ""
            if rem == 3:
                k, suffix = (k + 1) % 4, "_r3"
            elif rem == 1:
                suffix = "_r1"
            elif rem == 2:
                suffix = "_r2"
            v = {"model": f"{MODID}:block/{uid}{suffix}"}
            if k:
                v["y"] = 90 * k
            variants[f"rotation={r}"] = v
        save_json(os.path.join(ASSETS, "blockstates", f"{uid}.json"), {"variants": variants})
        save_json(os.path.join(ASSETS, "models/item", f"{uid}.json"), {"parent": f"{MODID}:block/{uid}"})
        loot = {"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MODID}:{uid}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}
    else:
        tl = tiles_of(parts, W, D, H)
        n = W * D * H
        for idx, ps in tl.items():
            save_json(os.path.join(ASSETS, "models/block", f"{uid}_p{idx}.json"),
                      {"parent": "minecraft:block/block", "textures": tex(fid), "elements": elements(ps)})
        variants = {}
        for fi, face in enumerate(("north", "east", "south", "west")):
            for idx in range(n):
                v = {"model": f"{MODID}:block/{uid}_p{idx}" if idx in tl else f"{MODID}:block/empty_{fid}"}
                if fi:
                    v["y"] = 90 * fi
                variants[f"facing={face},part={idx}"] = v
        save_json(os.path.join(ASSETS, "blockstates", f"{uid}.json"), {"variants": variants})
        f = min(1.0, 14.0 / max(W * 16, D * 16, H * 16) * 1.0)
        f = 14.0 / max(W * 16, D * 16, H * 16)
        ox, oy, oz = (16 - W * 16 * f) / 2, 1.0, (16 - D * 16 * f) / 2
        scaled = [[ox + p[0] * f, oy + p[1] * f, oz + p[2] * f, ox + p[3] * f, oy + p[4] * f, oz + p[5] * f, p[6]] for p in parts]
        scaled = [p for p in scaled if p[3] - p[0] > 0.02 and p[4] - p[1] > 0.02 and p[5] - p[2] > 0.02]
        save_json(os.path.join(ASSETS, "models/item", f"{uid}.json"),
                  {"parent": "minecraft:block/block", "textures": tex(fid), "elements": elements(scaled)})
        loot = {"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MODID}:{uid}"}],
                "conditions": [{"condition": "minecraft:survives_explosion"},
                               {"condition": "minecraft:block_state_property", "block": f"{MODID}:{uid}", "properties": {"part": "0"}}]}
    save_json(os.path.join(DATA, "loot_tables/blocks", f"{uid}.json"), {"type": "minecraft:block", "pools": [loot]})
    st = u["stats"]
    stats = f'M {st["M"]}  T {st["T"]}  Sv {st["Sv"]}  W {st["W"]}  Ld {st["Ld"]}  OC {st["OC"]}'
    if st["Inv"] not in ("-", "—"):
        stats += f'  Inv {st["Inv"]}'
    lang_en[f"block.{MODID}.{uid}"] = u["name"]
    lang_ru[f"block.{MODID}.{uid}"] = RU[uid] if USE_RU_NAMES else u["name"]
    lang_en[f"unitinfo.{MODID}.{uid}"] = stats
    lang_ru[f"unitinfo.{MODID}.{uid}"] = stats
    size = f"{W}×{D}×{H}"
    lang_en[f"unitrole.{MODID}.{uid}"] = f'{u["role"]} | {u["pts"]} pts | {size} blocks'
    lang_ru[f"unitrole.{MODID}.{uid}"] = f'{u["role"]} | {u["pts"]} очк. | {size} блоков'


def models40k_check(parts, W, D, H):
    for (x1, y1, z1, x2, y2, z2, s) in parts:
        assert x2 > x1 and y2 > y1 and z2 > z1
        assert x1 >= -0.01 and z1 >= -0.01 and y1 >= -0.01 and x2 <= W * 16 + 0.01 and z2 <= D * 16 + 0.01 and y2 <= H * 16 + 0.01


def main():
    for sub in ("models/block", "models/item", "blockstates", "textures/block", "textures/item"):
        shutil.rmtree(os.path.join(ASSETS, sub), ignore_errors=True)
    shutil.rmtree(os.path.join(DATA, "loot_tables"), ignore_errors=True)
    lang_en, lang_ru = {}, {}
    book_ids = books40k.write_books(os.path.join(ASSETS, "guides/ru"), data.UNITS)
    for fid, color, en, ru in FACTIONS:
        palette_texture(PAL[fid]).save(os.path.join(ASSETS, "textures/block", f"pal_{fid}.png")) if os.makedirs(os.path.join(ASSETS, "textures/block"), exist_ok=True) is None else None
        save_json(os.path.join(ASSETS, "models/block", f"empty_{fid}.json"), {"parent": "minecraft:block/block", "textures": tex(fid), "elements": []})
        lang_en[f"itemGroup.{MODID}.faction_{fid}"] = en
        lang_ru[f"itemGroup.{MODID}.faction_{fid}"] = ru
    lang_en[f"itemGroup.{MODID}.rules"] = "40K: Rules & Tools"
    lang_ru[f"itemGroup.{MODID}.rules"] = "40K: Правила и инструменты"
    for u in data.UNITS:
        emit_unit(u, lang_en, lang_ru)
    # markers
    for mid, color, glyph, en, ru in MARKERS:
        token_texture(color, glyph).save(os.path.join(ASSETS, "textures/block", f"{mid}.png"))
        save_json(os.path.join(ASSETS, "models/block", f"{mid}.json"), {
            "parent": "minecraft:block/block", "textures": {"t": f"{MODID}:block/{mid}", "particle": f"{MODID}:block/{mid}"},
            "elements": [{"from": [2, 0, 2], "to": [14, 1.5, 14], "faces": {
                "up": {"texture": "#t", "uv": [0, 0, 16, 16]}, "down": {"texture": "#t", "uv": [0, 0, 16, 16]},
                "north": {"texture": "#t", "uv": [0, 0, 16, 1]}, "south": {"texture": "#t", "uv": [0, 0, 16, 1]},
                "east": {"texture": "#t", "uv": [0, 0, 16, 1]}, "west": {"texture": "#t", "uv": [0, 0, 16, 1]}}}]})
        variants = {}
        for r in range(16):
            v = {"model": f"{MODID}:block/{mid}"}
            if round(r / 4) % 4:
                v["y"] = 90 * (round(r / 4) % 4)
            variants[f"rotation={r}"] = v
        save_json(os.path.join(ASSETS, "blockstates", f"{mid}.json"), {"variants": variants})
        save_json(os.path.join(ASSETS, "models/item", f"{mid}.json"), {"parent": f"{MODID}:block/{mid}"})
        save_json(os.path.join(DATA, "loot_tables/blocks", f"{mid}.json"), {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MODID}:{mid}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
        lang_en[f"block.{MODID}.{mid}"] = en
        lang_ru[f"block.{MODID}.{mid}"] = ru
    for name, img in tool_textures().items():
        img.save(os.path.join(ASSETS, "textures/item", f"{name}.png")) if os.makedirs(os.path.join(ASSETS, "textures/item"), exist_ok=True) is None else None
        save_json(os.path.join(ASSETS, "models/item", f"{name}.json"), {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MODID}:item/{name}"}})
    lang_en.update(LANG_EN)
    lang_ru.update(LANG_RU)
    save_json(os.path.join(ASSETS, "lang/en_us.json"), lang_en)
    save_json(os.path.join(ASSETS, "lang/ru_ru.json"), lang_ru)
    write_java(book_ids)
    print("units", len(data.UNITS), "lang", len(lang_en), len(lang_ru))


LANG_EN = {
    "item.warhammer40k.paint_remover": "Paint Remover", "tooltip.warhammer40k.paint_remover.1": "Right-click a miniature: restore the factory colour", "tooltip.warhammer40k.paint_remover.2": "To paint: right-click a miniature while holding any dye",
    "item.warhammer40k.move_tool": "Movement Tool", "item.warhammer40k.attack_tool": "Attack Tool",
    "tooltip.warhammer40k.move_tool.1": "Right-click a miniature: show how far it can move",
    "tooltip.warhammer40k.move_tool.2": "Click the same miniature again: Normal / Advance / Charge",
    "tooltip.warhammer40k.move_tool.3": "Shift+right-click: hide the zone",
    "tooltip.warhammer40k.attack_tool.1": "Right-click a miniature: show weapon range",
    "tooltip.warhammer40k.attack_tool.2": "Click the same miniature again: next weapon",
    "tooltip.warhammer40k.attack_tool.3": "Shift+right-click: hide the zone",
    "msg.warhammer40k.range.notunit": "This is not a miniature",
    "msg.warhammer40k.range.cleared": "Zone hidden",
    "msg.warhammer40k.range.immobile": "%s cannot move",
    "msg.warhammer40k.range.noweapons": "%s has no weapons",
    "msg.warhammer40k.move.normal": "%s: Normal move, up to %s\"",
    "msg.warhammer40k.move.advance": "%s: Advance, %s\" + D6 (yellow ring = maximum %s\")",
    "msg.warhammer40k.move.charge": "%s: Charge, declare within 12\" (roll 2D6)",
    "msg.warhammer40k.attack.ranged": "%s: %s - range %s\"",
    "msg.warhammer40k.attack.half": "%s: %s - range %s\" (yellow ring = half range %s\")",
    "msg.warhammer40k.attack.melee": "%s: %s - melee, engagement range 2\"",
    "item.warhammer40k.d6": "D6 Dice", "item.warhammer40k.ruler": "Ruler (inches)",
    "tooltip.warhammer40k.d6.1": "Right-click: roll as many D6 as the stack size",
    "tooltip.warhammer40k.d6.2": "Shift+right-click: roll 2D6 (charge, Battle-shock)",
    "tooltip.warhammer40k.d6.3": "Right-click a block: cycle the success target (2+...6+, off)",
    "tooltip.warhammer40k.ruler.1": "1 block = 1 inch",
    "tooltip.warhammer40k.ruler.2": "Click a block: point A. Click another: distance",
    "tooltip.warhammer40k.ruler.3": "Shift+click: new point A. Shift+right-click in air: reset",
    "tooltip.warhammer40k.place": "Placed facing where you look. Infantry: 22.5° steps; empty-hand right-click turns it",
    "tooltip.warhammer40k.big": "Multi-block model: needs free space, breaks as one piece",
    "msg.warhammer40k.d6.header": "%s rolls %s x D6:", "msg.warhammer40k.d6.header2": "%s rolls 2D6:",
    "msg.warhammer40k.d6.result": "Results: %s", "msg.warhammer40k.d6.sum": "Sum: %s",
    "msg.warhammer40k.d6.success": "Successes (%s+): %s of %s",
    "msg.warhammer40k.d6.target": "Success target: %s",
    "msg.warhammer40k.d6.target.off": "Success target: off",
    "msg.warhammer40k.ruler.set": "Point A: %s, %s", "msg.warhammer40k.ruler.reset": "Ruler reset",
    "msg.warhammer40k.ruler.result": "Distance: %s\" %s",
    "msg.warhammer40k.nospace": "Not enough free space for this model",
    "msg.warhammer40k.table.done": "Battlefield %sx%s inches built",
    "hover.warhammer40k.hint": "Hold the model in sight to see its profile",
}
LANG_RU = {
    "item.warhammer40k.paint_remover": "Растворитель краски", "tooltip.warhammer40k.paint_remover.1": "ПКМ по миниатюре: вернуть заводской цвет", "tooltip.warhammer40k.paint_remover.2": "Чтобы покрасить: ПКМ по миниатюре с любым красителем в руке",
    "item.warhammer40k.move_tool": "Инструмент движения", "item.warhammer40k.attack_tool": "Инструмент атаки",
    "tooltip.warhammer40k.move_tool.1": "ПКМ по миниатюре: показать зону хода",
    "tooltip.warhammer40k.move_tool.2": "Ещё раз по той же: обычный ход / Advance / чардж",
    "tooltip.warhammer40k.move_tool.3": "Shift+ПКМ: скрыть зону",
    "tooltip.warhammer40k.attack_tool.1": "ПКМ по миниатюре: показать дальность оружия",
    "tooltip.warhammer40k.attack_tool.2": "Ещё раз по той же: следующее оружие",
    "tooltip.warhammer40k.attack_tool.3": "Shift+ПКМ: скрыть зону",
    "msg.warhammer40k.range.notunit": "Это не миниатюра",
    "msg.warhammer40k.range.cleared": "Зона скрыта",
    "msg.warhammer40k.range.immobile": "%s не может двигаться",
    "msg.warhammer40k.range.noweapons": "У %s нет оружия",
    "msg.warhammer40k.move.normal": "%s: обычный ход, до %s\"",
    "msg.warhammer40k.move.advance": "%s: Advance, %s\" + D6 (жёлтое кольцо = максимум %s\")",
    "msg.warhammer40k.move.charge": "%s: чардж, объявить в пределах 12\" (бросок 2D6)",
    "msg.warhammer40k.attack.ranged": "%s: %s — дальность %s\"",
    "msg.warhammer40k.attack.half": "%s: %s — дальность %s\" (жёлтое кольцо = половина, %s\")",
    "msg.warhammer40k.attack.melee": "%s: %s — ближний бой, дистанция боя 2\"",
    "item.warhammer40k.d6": "Кубики D6", "item.warhammer40k.ruler": "Линейка (дюймы)",
    "tooltip.warhammer40k.d6.1": "ПКМ: бросить столько D6, сколько кубиков в стопке",
    "tooltip.warhammer40k.d6.2": "Shift+ПКМ: бросить 2D6 (чардж, Battle-shock)",
    "tooltip.warhammer40k.d6.3": "ПКМ по блоку: цель успеха (2+...6+, выкл.)",
    "tooltip.warhammer40k.ruler.1": "1 блок = 1 дюйм",
    "tooltip.warhammer40k.ruler.2": "ПКМ по блоку: точка A. По другому: расстояние",
    "tooltip.warhammer40k.ruler.3": "Shift+ПКМ по блоку: новая точка A. Shift+ПКМ в воздух: сброс",
    "tooltip.warhammer40k.place": "Ставится носом туда, куда вы смотрите. Пехота: шаг 22,5°; ПКМ пустой рукой поворачивает",
    "tooltip.warhammer40k.big": "Многоблочная модель: нужно свободное место, ломается целиком",
    "msg.warhammer40k.d6.header": "%s бросает %s × D6:", "msg.warhammer40k.d6.header2": "%s бросает 2D6:",
    "msg.warhammer40k.d6.result": "Выпало: %s", "msg.warhammer40k.d6.sum": "Сумма: %s",
    "msg.warhammer40k.d6.success": "Успехов (%s+): %s из %s",
    "msg.warhammer40k.d6.target": "Цель успеха: %s",
    "msg.warhammer40k.d6.target.off": "Цель успеха: выкл.",
    "msg.warhammer40k.ruler.set": "Точка A: %s, %s", "msg.warhammer40k.ruler.reset": "Линейка сброшена",
    "msg.warhammer40k.ruler.result": "Расстояние: %s\" %s",
    "msg.warhammer40k.nospace": "Недостаточно места для этой модели",
    "msg.warhammer40k.table.done": "Поле %sx%s дюймов построено",
    "hover.warhammer40k.hint": "Наведите на модель, чтобы увидеть профиль",
}


def jstr(t):
    return '"' + t.replace("\\", "\\\\").replace('"', '\\"') + '"'


def unit_java(u):
    m = re.match(r"\d+", u["stats"]["M"])
    move = int(m.group()) if m else 0
    groups = {}
    for w in u["weapons"]:
        r = w["rng"]
        if r.lower().startswith("melee"):
            rng = 0
        else:
            m2 = re.match(r"\d+", r)
            if not m2:
                continue
            rng = int(m2.group())
        g = groups.setdefault(rng, {"names": [], "half": False})
        if w["name"] not in g["names"]:
            g["names"].append(w["name"])
        if re.search(r"rapid fire|melta", w["abil"], re.I):
            g["half"] = True
    ws = []
    for rng in sorted(groups, reverse=True):
        g = groups[rng]
        names = ", ".join(g["names"][:3]) + ("..." if len(g["names"]) > 3 else "")
        ws.append("new Weapon(%s, %d, %s)" % (jstr(names), rng, "true" if g["half"] else "false"))
    wl = "List.of(" + ", ".join(ws) + ")" if ws else "List.of()"
    return '        new Unit("%s", "%s", %d, %d, %d, %d, %s)' % (u["id"], u["fac"], u["dims"][0], u["dims"][1], u["dims"][2], move, wl)


def write_java(book_ids):
    L = ["package dev.w40k;", "", "import java.util.List;", "import java.util.Map;", "",
         "/** GENERATED by tools/gen.py - do not edit. */", "public final class UnitData {", "    private UnitData() {}", "",
         "    public record Faction(String id, int color) {}",
         "    /** w, d, h = footprint in blocks (1 block = 1 inch). */",
         "    /** range in inches; 0 = melee (engagement range). half = Rapid Fire / Melta style bonus at half range. */",
         "    public record Weapon(String names, int range, boolean half) {}",
         "    /** move = M characteristic in inches (0 = cannot move). */",
         "    public record Unit(String id, String faction, int w, int d, int h, int move, List<Weapon> weapons) {}", "",
         "    public static Unit find(String id) {",
         "        for (Unit u : UNITS) {",
         "            if (u.id().equals(id)) {",
         "                return u;",
         "            }",
         "        }",
         "        return null;",
         "    }", "",
         "    public static final List<Faction> FACTIONS = List.of("]
    L.append(",\n".join(f'        new Faction("{f}", 0x{c:06X})' for f, c, _, _ in FACTIONS))
    L.append("    );\n")
    L.append("    public static final List<Unit> UNITS = List.of(")
    L.append(",\n".join(unit_java(u) for u in data.UNITS))
    L.append("    );\n")
    L.append("    public static final Map<String, List<String>> BOOKS = Map.of(")
    L.append(",\n".join('        "%s", List.of(%s)' % (k, ", ".join('"%s"' % b for b in v)) for k, v in book_ids.items() if not k.startswith("_")))
    L.append("    );\n")
    L.append("    public static final List<String> MARKERS = List.of(" + ", ".join('"%s"' % m[0] for m in MARKERS) + ");")
    L.append("}")
    write(JAVA, "\n".join(L) + "\n")


if __name__ == "__main__":
    main()

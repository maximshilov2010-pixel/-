"""Cuboid miniature models for Warhammer 40,000 units. Coordinates are pixels (16 px = 1 block = 1 inch)
inside the unit's footprint: x 0..W*16, y 0..H*16, z 0..D*16, bow/front = NORTH (small z)."""
import math
import random

M, D, L, S, K, G, W_, A = range(8)  # main, dark, light, steel, black, gold, white, accent(glow)


def b(x1, y1, z1, x2, y2, z2, slot):
    return [x1, y1, z1, x2, y2, z2, slot]


def sc(parts, f, ox=0.0, oy=0.0, oz=0.0, fy=None):
    fy = f if fy is None else fy
    return [[ox + p[0] * f, oy + p[1] * fy, oz + p[2] * f, ox + p[3] * f, oy + p[4] * fy, oz + p[5] * f, p[6]] for p in parts]


def mirror_x(parts, cx=8.0):
    return [[2 * cx - p[3], p[1], p[2], 2 * cx - p[0], p[4], p[5], p[6]] for p in parts]


def hum(weapon="gauss", shield=False, cape=False, crown=False, fly=False, bulky=False, destroyer=False,
        robe=False, noble=False):
    """Humanoid in a 16x16x16 cell, ~14 px tall."""
    y0 = 1.6 if fly else 0.0
    p = [b(4, 0, 4, 12, 1, 12, D)]
    if fly:
        p = [b(4.5, 0, 4.5, 11.5, 0.6, 11.5, D), b(5.5, 0.6, 5.5, 10.5, 1.0, 10.5, A), b(7, 1.0, 7, 9, 1.6, 9, S)]
    if robe:  # Skitarii: long robe
        p += [b(5, y0 + 1, 6.2, 11, y0 + 8.5, 9.8, A), b(4.6, y0 + 7, 6, 11.4, y0 + 11, 10, A)]
    else:
        lw = 2.4 if bulky else 2.0
        p += [b(5.2, y0 + 1, 7, 5.2 + lw, y0 + 6, 9.2, S), b(10.8 - lw, y0 + 1, 7, 10.8, y0 + 6, 9.2, S),
              b(5, y0 + 6, 6.4, 11, y0 + 7.4, 9.6, D)]
        p += [b(4.8, y0 + 7.4, 6, 11.2, y0 + 11.6, 10, M if not destroyer else D), b(6.8, y0 + 8.6, 5.8, 9.2, y0 + 10.4, 6.1, A)]
    p += [b(3.6, y0 + 10.2, 6.2, 5.2, y0 + 11.8, 9.8, S), b(10.8, y0 + 10.2, 6.2, 12.4, y0 + 11.8, 9.8, S)]
    p += [b(6.4, y0 + 11.6, 6.6, 9.6, y0 + 14.2, 9.4, S if not robe else D), b(6.9, y0 + 12.6, 6.4, 7.7, y0 + 13.3, 6.6, A),
          b(8.3, y0 + 12.6, 6.4, 9.1, y0 + 13.3, 6.6, A)]
    if robe:
        p += [b(6.2, y0 + 13.8, 6.4, 9.8, y0 + 15, 9.8, A)]
    if destroyer:
        p += [b(5.5, y0 + 14.2, 7.2, 10.5, y0 + 15.2, 8.8, G), b(3.2, y0 + 11.6, 6, 5.2, y0 + 12.8, 10, G), b(10.8, y0 + 11.6, 6, 12.8, y0 + 12.8, 10, G)]
    if crown:
        p += [b(6.4, y0 + 14.2, 7.2, 9.6, y0 + 15.4, 8.8, G), b(7.6, y0 + 15.4, 7.6, 8.4, y0 + 16, 8.4, G)]
    if noble:
        p += [b(6.4, y0 + 14.2, 7.2, 9.6, y0 + 14.8, 8.8, G)]
    if cape:
        p += [b(5.2, y0 + 3, 9.6, 10.8, y0 + 12, 10.4, D)]
    arms = []
    if weapon == "gauss":
        arms = [b(3.8, y0 + 8, 5, 4.8, y0 + 10.2, 7, S), b(10.8, y0 + 8.5, 2.5, 11.8, y0 + 9.8, 8.5, K),
                b(11, y0 + 8.7, 1.8, 11.6, y0 + 9.4, 2.5, A), b(3.8, y0 + 8, 5.2, 4.8, y0 + 10, 7, S)]
    elif weapon == "sniper":
        arms = [b(10.9, y0 + 9, 0.5, 11.5, y0 + 9.6, 9, K), b(10.6, y0 + 9.6, 5, 11.8, y0 + 10.4, 6.5, S), b(11, y0 + 9, 0.2, 11.5, y0 + 9.6, 0.5, A)]
    elif weapon == "scythe":
        arms = [b(11.2, y0 + 0, 7.6, 11.8, y0 + 14.5, 8.2, K), b(9.2, y0 + 13.6, 7.4, 12.6, y0 + 14.6, 8.4, S),
                b(8.8, y0 + 12.4, 7.4, 9.6, y0 + 13.6, 8.4, S), b(7.8, y0 + 11.4, 7.4, 8.8, y0 + 12.4, 8.4, S)]
    elif weapon == "claws":
        arms = [b(3.2, y0 + 8.5, 2.5, 4.4, y0 + 9.7, 7, S), b(11.6, y0 + 8.5, 2.5, 12.8, y0 + 9.7, 7, S),
                b(3, y0 + 8.2, 1, 3.5, y0 + 10, 2.5, W_), b(4.1, y0 + 8.2, 1, 4.6, y0 + 10, 2.5, W_),
                b(11.4, y0 + 8.2, 1, 11.9, y0 + 10, 2.5, W_), b(12.5, y0 + 8.2, 1, 13, y0 + 10, 2.5, W_)]
    elif weapon == "blade":
        arms = [b(11, y0 + 7.5, 5, 12, y0 + 9, 7, S), b(11.2, y0 + 8, 1.0, 11.8, y0 + 8.6, 7, W_), b(10.4, y0 + 7.7, 6.6, 12.6, y0 + 8.3, 7.1, G)]
    elif weapon == "staff":
        arms = [b(11.4, y0 + 0, 6.2, 12, y0 + 15, 6.8, G), b(11, y0 + 15, 5.8, 12.4, y0 + 16, 7.2, A)]
    elif weapon == "rod":
        arms = [b(11.2, y0 + 7, 3, 11.8, y0 + 8.6, 8.4, G), b(10.8, y0 + 7.2, 2.2, 12.2, y0 + 8.4, 3, A)]
    elif weapon == "pistols":
        arms = [b(3.4, y0 + 8.3, 3.5, 4.6, y0 + 9.3, 7, K), b(11.4, y0 + 8.3, 3.5, 12.6, y0 + 9.3, 7, K)]
    elif weapon == "rifle":
        arms = [b(10.6, y0 + 8, 2, 11.6, y0 + 9.4, 9, K), b(10.9, y0 + 8.3, 1.4, 11.3, y0 + 8.9, 2, S)]
    elif weapon == "carbine":
        arms = [b(10.7, y0 + 8.2, 3.5, 11.6, y0 + 9.4, 9, K), b(10.9, y0 + 8.4, 2.8, 11.4, y0 + 9, 3.5, A)]
    elif weapon == "pistol":
        arms = [b(11, y0 + 8.3, 4, 11.8, y0 + 9.2, 7, K)]
    if not robe:
        # feet, knee guards, belt, backpack, shoulder pads, ribs: extra detail for the small models
        p += [b(4.9, y0, 6.4, 7.5, y0 + 1.1, 9.8, K), b(8.5, y0, 6.4, 11.1, y0 + 1.1, 9.8, K),
              b(5.0, y0 + 3.4, 6.4, 7.4, y0 + 4.4, 7.0, D), b(8.6, y0 + 3.4, 6.4, 11.0, y0 + 4.4, 7.0, D),
              b(7.4, y0 + 6.4, 6.2, 8.6, y0 + 7.1, 6.5, G),
              b(5.6, y0 + 7.6, 9.8, 10.4, y0 + 11, 11.2, D), b(6.4, y0 + 9, 11.2, 9.6, y0 + 10, 11.6, A),
              b(3.2, y0 + 11.6, 6, 5.2, y0 + 12.4, 10, D), b(10.8, y0 + 11.6, 6, 12.8, y0 + 12.4, 10, D)]
        for i in range(3):
            p += [b(6.0, y0 + 8.0 + i * 0.9, 5.9, 10.0, y0 + 8.3 + i * 0.9, 6.0, S)]
        p += [b(7.4, y0 + 14.2, 6.8, 8.6, y0 + 15.4, 9.2, D)]
    p += arms
    if shield:
        p += [b(1.8, y0 + 4, 4.6, 3.8, y0 + 12.5, 9.4, S), b(1.5, y0 + 6, 5.8, 1.8, y0 + 10.5, 8.2, G)]
    return p


def hum_scaled(f, W, D_, **kw):
    cx, cz = W * 8.0, D_ * 8.0
    return sc(hum(**kw), f, cx - 8 * f, 0, cz - 8 * f)


def serpent(W, D_, H, wraith=False):
    cx, cz = W * 8, D_ * 8
    p = []
    ln = D_ * 16
    n = 7
    for i in range(n):
        z = ln - 2 - i * (ln - 6) / n
        w = 5 - i * 0.45
        y = 1 + (i * 0.5 if i < 3 else 1.5 + i * 0.2)
        p.append(b(cx - w / 2, y, z - 3, cx + w / 2, y + w * 0.9, z, M if i % 2 == 0 else D))
    p += [b(cx - 3, 4, 3, cx + 3, 10, 7, S), b(cx - 2, 7, 2.5, cx - 0.8, 8.2, 3, A), b(cx + 0.8, 7, 2.5, cx + 2, 8.2, 3, A),
          b(cx - 3.5, 3, 6, cx - 2, 9, 9, S), b(cx + 2, 3, 6, cx + 3.5, 9, 9, S)]
    p += [b(cx - 5.2, 5, 2, cx - 4.2, 10, 8, W_), b(cx + 4.2, 5, 2, cx + 5.2, 10, 8, W_)]
    if wraith:
        p += [b(cx - 8, 2, 4, cx - 7, 3, 12, A), b(cx + 7, 2, 4, cx + 8, 3, 12, A), b(cx - 4, 10, 6, cx + 4, 12, 7, G)]
    return p


def crawler(W, D_, H, acan=False, spyder=False, reanim=False):
    cx, cz = W * 8, D_ * 8
    hw = W * 8 - 3
    p = [b(cx - hw * 0.45, H * 3.0, cz - D_ * 3, cx + hw * 0.45, H * 3.0 + 5, cz + D_ * 3.4, M),
         b(cx - hw * 0.3, H * 3.0 + 5, cz - D_ * 2, cx + hw * 0.3, H * 3.0 + 7, cz + D_ * 2.4, D)]
    for i, zf in enumerate((-0.55, 0.0, 0.55)):
        z = cz + zf * D_ * 4
        for sx in (-1, 1):
            x0 = cx + sx * hw * 0.4
            x1 = cx + sx * hw * 0.95
            p += [b(min(x0, x1), H * 3.0 + 2, z - 0.4, max(x0, x1), H * 3.0 + 3.2, z + 0.4, S),
                  b(x1 - 0.4 if sx > 0 else x1 - 0.4, 0, z - 0.4, x1 + 0.4, H * 3.0 + 3.2, z + 0.4, S)]
    p += [b(cx - 2, H * 3 + 3, cz - D_ * 3 - 2, cx + 2, H * 3 + 6, cz - D_ * 3 + 1, S), b(cx - 1.4, H * 3 + 4, cz - D_ * 3 - 2.4, cx - 0.4, H * 3 + 5, cz - D_ * 3 - 2, A),
          b(cx + 0.4, H * 3 + 4, cz - D_ * 3 - 2.4, cx + 1.4, H * 3 + 5, cz - D_ * 3 - 2, A)]
    p += [b(cx - hw * 0.75, H * 3 + 2, cz - D_ * 4.2, cx - hw * 0.45, H * 3 + 5, cz - D_ * 2, W_),
          b(cx + hw * 0.45, H * 3 + 2, cz - D_ * 4.2, cx + hw * 0.75, H * 3 + 5, cz - D_ * 2, W_)]
    if acan:
        p += [b(cx - 0.6, H * 3 + 5.5, cz - D_ * 4.6, cx + 0.6, H * 3 + 6.7, cz - D_ * 2, K), b(cx - 0.6, H * 3 + 5.5, cz - D_ * 4.8, cx + 0.6, H * 3 + 6.7, cz - D_ * 4.6, A)]
    if spyder:
        p += [b(cx - 4, H * 3 + 7, cz - 2, cx + 4, H * 3 + 11, cz + 4, M), b(cx - 5, 0, cz - 5, cx + 5, 1, cz + 5, A)]
    if reanim:
        p += [b(cx - 5, H * 3 + 7, cz - 3, cx + 5, H * 3 + 8.5, cz + 5, S), b(cx - 1, H * 3 + 8.5, cz, cx + 1, H * 3 + 12, cz + 2, A)]
    return p


def swarm(W, D_, H, seed=7):
    r = random.Random(seed)
    p = [b(2, 0, 2, W * 16 - 2, 0.6, D_ * 16 - 2, D)]
    for _ in range(26):
        x, z = r.uniform(2, W * 16 - 4), r.uniform(2, D_ * 16 - 4)
        y = r.uniform(0.6, H * 16 * 0.5)
        s = r.uniform(1.4, 2.4)
        p += [b(x, y, z, x + s, y + s * 0.8, z + s * 1.2, M if r.random() < .6 else S), b(x + s * 0.3, y + s * 0.8, z, x + s * 0.7, y + s, z + 0.4, A)]
    return p


def drone(W, D_, H):
    cx, cz = 8, 8
    return [b(6, 5, 5, 10, 8, 11, M), b(5, 6, 3.5, 11, 7, 5, S), b(7, 4, 4, 9, 5, 12, D), b(5, 7.5, 9, 7, 8.5, 12, A), b(9, 7.5, 9, 11, 8.5, 12, A),
            b(7.3, 3, 3, 8.7, 5, 3.5, K), b(4.5, 8, 6, 5.5, 9.5, 11, W_), b(10.5, 8, 6, 11.5, 9.5, 11, W_), b(6.5, 0, 6.5, 9.5, 1, 9.5, A)]


def blade(W, D_, H):  # Tomb Blade
    return [b(7, 3.5, 1.5, 9, 6.5, 13, M), b(6, 5, 3, 10, 6, 11, D), b(3, 5.2, 5, 13, 5.9, 11, S), b(2, 5, 8, 3.2, 6.2, 12, A), b(12.8, 5, 8, 14, 6.2, 12, A),
            b(7.2, 6.5, 6, 8.8, 10.5, 9, S), b(7.3, 10.5, 6.2, 8.7, 12.5, 8.4, S), b(7.6, 11, 6, 8.4, 11.6, 6.2, A), b(7.4, 2, 12, 8.6, 5, 15.5, S),
            b(7.4, 5.8, 0.5, 8.6, 6.6, 3, K), b(6.5, 0.2, 6, 9.5, 3, 9, A)]


def lokhust(W, D_, H, heavy=False, lord=False):
    p = [b(11, 4, 3, 21, 8, 29, M), b(8, 5, 6, 24, 6.2, 26, D), b(4, 5.4, 10, 28, 6.4, 24, S), b(3, 5, 14, 5, 7, 22, A), b(27, 5, 14, 29, 7, 22, A),
         b(13, 1, 8, 19, 4, 24, D), b(14, 8, 6, 18, 10, 26, S), b(14.2, 5, 29, 17.8, 7.5, 31.5, K), b(12, 0.2, 10, 20, 1.4, 22, A)]
    rider = sc(hum(weapon="blade" if lord else "gauss", cape=lord, crown=lord), 0.8, 9.6, 8, 12)
    p += rider
    gun = [b(12.5, 7, 0.5, 14, 8.5, 14, K), b(12.7, 7.2, 0, 13.8, 8.3, 0.5, A)] if not heavy else \
          [b(11, 7, -0.0 + 0.5, 15, 10, 13, K), b(11.5, 7.5, 0, 14.5, 9.5, 0.5, A), b(17.5, 8, 0.5, 20.5, 10, 8, K), b(17.8, 8.4, 0, 20.2, 9.6, 0.5, A)]
    p += gun
    return p


def barge(W, D_, H, lord=False):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - 12, 3, cz - 13, cx + 12, 7, cz + 13, M), b(cx - 14, 4, cz - 8, cx + 14, 6, cz + 12, D), b(cx - 10, 7, cz - 8, cx + 10, 8, cz + 12, L),
         b(cx - 6, 0.5, cz - 6, cx + 6, 3, cz + 6, A), b(cx - 3, 0, cz - 3, cx + 3, 0.5, cz + 3, A), b(cx - 1, 7, cz - 15, cx + 1, 9, cz - 12, K),
         b(cx - 13, 6, cz + 6, cx - 11, 11, cz + 14, S), b(cx + 11, 6, cz + 6, cx + 13, 11, cz + 14, S), b(cx - 1.5, 7, cz - 12, cx + 1.5, 10, cz - 4, K),
         b(cx - 1, 10, cz - 14, cx + 1, 12, cz - 4, S), b(cx - 0.6, 10.4, cz - 15, cx + 0.6, 11.6, cz - 14, A)]
    p += sc(hum(weapon="blade" if lord else "gauss", cape=lord, crown=lord), 0.95, cx - 7.6, 8, cz + 1)
    return p


def ark(W, D_, H, kind="ghost"):
    w, d = W * 16, D_ * 16
    cx = w / 2
    p = [b(cx - 11, 3, 4, cx + 11, 7, d - 3, M), b(cx - 13, 4.5, 8, cx + 13, 6.5, d - 6, D), b(cx - 8, 7, 8, cx + 8, 8, d - 5, L),
         b(cx - 5, 0.4, 14, cx + 5, 3, d - 12, A), b(cx - 2, 7, 1, cx + 2, 9, 5, K), b(cx - 1, 9, 2, cx + 1, 11, 6, S)]
    p += [b(cx - 10, 8, d - 14, cx - 9, 13, d - 4, S), b(cx + 9, 8, d - 14, cx + 10, 13, d - 4, S)]
    if kind == "ghost":
        for i in range(4):
            z = 14 + i * 7
            p += [b(cx - 5, 8, z, cx + 5, 11, z + 4, W_), b(cx - 4, 11, z + 0.5, cx + 4, 11.6, z + 3.5, G)]
        p += [b(cx - 4, 8, 5, cx + 4, 12, 10, S), b(cx - 3, 12, 6, cx + 3, 13, 9, A)]
    elif kind == "doomsday":
        p += [b(cx - 2.5, 8, 2, cx + 2.5, 13, d - 8, K), b(cx - 3.2, 13, 8, cx + 3.2, 14.5, d - 10, S), b(cx - 1.5, 9.5, -0.0 + 0.5, cx + 1.5, 11.5, 2, A)]
        p += [b(cx - 7, 8, d - 12, cx - 3, 12, d - 6, S), b(cx + 3, 8, d - 12, cx + 7, 12, d - 6, S)]
    elif kind == "tesseract":
        p += [b(cx - 5, 8, 14, cx + 5, 18, 24, S), b(cx - 4, 9, 15, cx + 4, 17, 23, A), b(cx - 6, 13, 13, cx + 6, 14, 25, G)]
        p += [b(cx - 7, 8, 4, cx - 4, 10.5, 12, K), b(cx + 4, 8, 4, cx + 7, 10.5, 12, K)]
    return p


def scythe(W, D_, H, kind="doom"):
    w, d = W * 16, D_ * 16
    cx = w / 2
    p = [b(cx - 5, 8, 6, cx + 5, 13, d - 8, M), b(cx - 3, 13, 14, cx + 3, 15, d - 14, S), b(cx - 3.5, 7, 3, cx + 3.5, 10, 8, D), b(cx - 1, 9, 1, cx + 1, 11, 3.5, A),
         b(cx - 2, 8, d - 8, cx + 2, 12, d - 2, D), b(cx - 14, 9, d - 3, cx + 14, 10.2, d + 0, D) if False else b(cx - 10, 9, d - 6, cx + 10, 10, d - 3, D),
         b(cx - 1, 3, cx / 2 + 10, cx + 1, 8, cx / 2 + 14, S), b(cx - 6, 1, cx / 2 + 8, cx + 6, 3, cx / 2 + 16, D)]
    for sx in (-1, 1):
        for i in range(5):
            x0 = cx + sx * (5 + i * 7)
            x1 = cx + sx * (12 + i * 7)
            z0 = 10 + i * 3.2
            p.append(b(min(x0, x1), 10 - i * 0.2, z0, max(x0, x1), 11 - i * 0.2, z0 + 11 - i * 1.3, M if i % 2 == 0 else D))
        p.append(b(cx + sx * 38 - 1, 9.5, 24, cx + sx * 38 + 1, 12, 30, A))
    if kind == "doom":
        p += [b(cx - 1, 9, 0.2, cx + 1, 12, 7, K), b(cx - 6, 10, 4, cx - 3, 12, 11, K), b(cx + 3, 10, 4, cx + 6, 12, 11, K)]
    elif kind == "night":
        p += [b(cx - 4, 13, 18, cx + 4, 15, 30, A), b(cx - 7, 10.5, 18, cx - 6, 12, 34, S), b(cx + 6, 10.5, 18, cx + 7, 12, 34, S)]
    elif kind == "shroud":
        p += [b(cx - 9, 11, 16, cx + 9, 12, 22, A), b(cx - 6, 12, 10, cx + 6, 13, 14, G)]
    return p


def monolith(W, D_, H):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p = [b(4, 0, 4, w - 4, 3, d - 4, D), b(8, 3, 8, w - 8, 14, d - 8, M), b(14, 14, 14, w - 14, 28, d - 14, M), b(20, 28, 20, w - 20, 40, d - 20, M),
         b(26, 40, 26, w - 26, 52, d - 26, D), b(cx - 6, 52, cz - 6, cx + 6, 56, cz + 6, G)]
    p += [b(cx - 5, 6, 7, cx + 5, 22, 8.2, A), b(cx - 3, 8, 6.5, cx + 3, 18, 7, K), b(cx - 14, 14, 13, cx - 12, 26, 14, A), b(cx + 12, 14, 13, cx + 14, 26, 14, A),
          b(cx - 1, 29, 19, cx + 1, 38, 20, A), b(cx - 10, 3, 6, cx - 9, 10, 8, G), b(cx + 9, 3, 6, cx + 10, 10, 8, G)]
    return p


def obelisk(W, D_, H):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - 20, 0, cz - 14, cx + 20, 4, cz + 14, D), b(cx - 16, 4, cz - 11, cx + 16, 12, cz + 11, M), b(cx - 12, 12, cz - 9, cx + 12, 36, cz + 9, M),
         b(cx - 9, 36, cz - 7, cx + 9, 56, cz + 7, M), b(cx - 6, 56, cz - 5, cx + 6, 70, cz + 5, D), b(cx - 3, 70, cz - 3, cx + 3, 76, cz + 3, G),
         b(cx - 1.2, 14, cz - 9.4, cx + 1.2, 34, cz - 9, A), b(cx - 1, 38, cz - 7.4, cx + 1, 54, cz - 7, A), b(cx - 0.8, 58, cz - 5.4, cx + 0.8, 68, cz - 5, A),
         b(cx - 8, 20, cz - 9.4, cx - 6, 22, cz - 9, A), b(cx + 6, 20, cz - 9.4, cx + 8, 22, cz - 9, A), b(cx - 8, 28, cz - 9.4, cx - 6, 30, cz - 9, A), b(cx + 6, 28, cz - 9.4, cx + 8, 30, cz - 9, A)]
    return p


def vault(W, D_, H):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    return [b(cx - 24, 6, cz - 18, cx + 24, 14, cz + 18, M), b(cx - 28, 8, cz - 10, cx + 28, 11, cz + 14, D), b(cx - 14, 14, cz - 12, cx + 14, 22, cz + 12, S),
            b(cx - 10, 22, cz - 8, cx + 10, 40, cz + 8, K), b(cx - 8, 24, cz - 9, cx + 8, 38, cz - 8, A), b(cx - 12, 30, cz - 10, cx + 12, 32, cz + 10, G),
            b(cx - 18, 14, cz - 4, cx - 14, 30, cz + 4, M), b(cx + 14, 14, cz - 4, cx + 18, 30, cz + 4, M), b(cx - 14, 0.5, cz - 10, cx + 14, 6, cz + 10, A),
            b(cx - 3, 40, cz - 3, cx + 3, 56, cz + 3, A), b(cx - 20, 14, cz - 20, cx - 16, 24, cz - 14, S), b(cx + 16, 14, cz - 20, cx + 20, 24, cz - 14, S)]


def construct(W, D_, H):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = []
    for lx, lz in ((-26, -18), (26, -18), (-26, 16), (26, 16)):
        p += [b(cx + lx - 5, 0, cz + lz - 5, cx + lx + 5, 8, cz + lz + 5, D), b(cx + lx - 4, 8, cz + lz - 4, cx + lx + 4, 24, cz + lz + 4, M),
              b(cx + lx - 5, 24, cz + lz - 5, cx + lx + 5, 28, cz + lz + 5, S)]
    p += [b(cx - 30, 28, cz - 24, cx + 30, 56, cz + 24, M), b(cx - 24, 56, cz - 18, cx + 24, 66, cz + 18, D), b(cx - 14, 66, cz - 12, cx + 14, 78, cz + 8, S),
          b(cx - 6, 70, cz - 13, cx + 6, 76, cz - 12, A), b(cx - 8, 56, cz - 28, cx + 8, 66, cz - 18, K), b(cx - 2, 58, cz - 36, cx + 2, 64, cz - 28, A),
          b(cx - 34, 50, cz - 10, cx - 30, 62, cz + 10, G), b(cx + 30, 50, cz - 10, cx + 34, 62, cz + 10, G), b(cx - 20, 66, cz + 8, cx - 12, 80, cz + 16, K), b(cx + 12, 66, cz + 8, cx + 20, 80, cz + 16, K)]
    return p


def pylon(W, D_, H, big=False):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - w / 2 + 3, 0, cz - d / 2 + 3, cx + w / 2 - 3, 4, cz + d / 2 - 3, D), b(cx - w / 4, 4, cz - d / 4, cx + w / 4, h * 0.55, cz + d / 4, M),
         b(cx - w / 8, h * 0.55, cz - d / 8, cx + w / 8, h * 0.85, cz + d / 8, M), b(cx - 2, h * 0.3, cz - d / 4 - 0.4, cx + 2, h * 0.7, cz - d / 4, A),
         b(cx - 3, h * 0.85, cz - 3, cx + 3, h * 0.9, cz + 3, G), b(cx - 1.5, h * 0.9, cz - 1.5, cx + 1.5, h * 0.98, cz + 1.5, A)]
    for sx in (-1, 1):
        p += [b(cx + sx * w / 3 - 2, 4, cz - 2, cx + sx * w / 3 + 2, h * 0.35, cz + 2, S)]
    return p


def pylon_small(W, D_, H):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    return [b(4, 0, 4, w - 4, 3, d - 4, D), b(cx - 5, 3, cz - 5, cx + 5, h * 0.5, cz + 5, M), b(cx - 3, h * 0.5, cz - 3, cx + 3, h * 0.8, cz + 3, M),
            b(cx - 1, h * 0.8, cz - 1, cx + 1, h * 0.95, cz + 1, A), b(cx - 1, 8, cz - 5.4, cx + 1, h * 0.45, cz - 5, A), b(cx - 4, h * 0.5, cz - 4, cx + 4, h * 0.5 + 1.2, cz + 4, G)]


def walls(W, D_, H):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p = [b(0, 0, cz - 10, w, 6, cz + 10, D), b(2, 6, cz - 8, w - 2, 30, cz + 8, M), b(0, 30, cz - 10, w, 34, cz + 10, D)]
    for i in range(int(w // 10)):
        p.append(b(2 + i * 10, 34, cz - 9, 8 + i * 10, 40, cz + 9, M))
    p += [b(cx - 10, 6, cz - 8.6, cx + 10, 26, cz - 8, K), b(cx - 8, 8, cz - 9, cx + 8, 10, cz - 8.6, A), b(cx - 12, 6, cz - 9, cx - 10, 30, cz - 8, G), b(cx + 10, 6, cz - 9, cx + 12, 30, cz - 8, G),
          b(8, 36, cz - 4, 12, 44, cz + 4, S), b(w - 12, 36, cz - 4, w - 8, 44, cz + 4, S)]
    return p


def ctan(W, D_, H, kind="nightbringer"):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    body = G if kind in ("deceiver", "transcendent") else (D if kind == "nightbringer" else M)
    p = [b(cx - w * 0.3, 0, cz - d * 0.3, cx + w * 0.3, 3, cz + d * 0.3, D)]
    if kind == "nightbringer":
        p += [b(cx - 9, 3, cz - 5, cx + 9, 26, cz + 6, K), b(cx - 12, 26, cz - 6, cx + 12, 44, cz + 6, K), b(cx - 6, 44, cz - 5, cx + 6, 56, cz + 5, S),
              b(cx - 3, 50, cz - 5.4, cx - 1, 52.5, cz - 5, A), b(cx + 1, 50, cz - 5.4, cx + 3, 52.5, cz - 5, A), b(cx - 8, 10, cz - 6, cx + 8, 12, cz - 5.4, A),
              b(cx + 16, 0, cz - 1, cx + 18, 70, cz + 1, K), b(cx + 8, 64, cz - 2, cx + 26, 70, cz + 2, S), b(cx + 22, 56, cz - 2, cx + 26, 64, cz + 2, S),
              b(cx + 12, 28, cz - 2, cx + 16, 40, cz + 2, K), b(cx - 16, 30, cz - 2, cx - 12, 42, cz + 2, K)]
    elif kind == "deceiver":
        p += [b(cx - 6, 3, cz - 4, cx + 6, 26, cz + 4, G), b(cx - 9, 26, cz - 5, cx + 9, 44, cz + 5, G), b(cx - 5, 44, cz - 4, cx + 5, 54, cz + 4, G),
              b(cx - 3, 48, cz - 4.4, cx - 1, 50, cz - 4, A), b(cx + 1, 48, cz - 4.4, cx + 3, 50, cz - 4, A), b(cx - 13, 24, cz - 4, cx - 9, 42, cz + 4, G),
              b(cx + 9, 24, cz - 4, cx + 13, 42, cz + 4, G), b(cx - 15, 22, cz - 8, cx - 8, 30, cz - 3, W_), b(cx + 8, 22, cz - 8, cx + 15, 30, cz - 3, W_)]
    elif kind == "voiddragon":
        p += [b(cx - 14, 4, cz - 10, cx + 14, 30, cz + 12, M), b(cx - 18, 30, cz - 8, cx + 18, 52, cz + 8, M), b(cx - 8, 52, cz - 8, cx + 8, 66, cz + 6, S),
              b(cx - 5, 58, cz - 8.4, cx - 2, 61, cz - 8, A), b(cx + 2, 58, cz - 8.4, cx + 5, 61, cz - 8, A), b(cx - 6, 8, cz + 10, cx + 6, 22, cz + h * 0.4 + 12, M),
              b(cx - 30, 40, cz + 2, cx - 18, 70, cz + 4, D), b(cx + 18, 40, cz + 2, cx + 30, 70, cz + 4, D), b(cx - 28, 66, cz + 1, cx - 18, 68, cz + 5, A), b(cx + 18, 66, cz + 1, cx + 28, 68, cz + 5, A),
              b(cx + 20, 0, cz - 20, cx + 22, 64, cz - 18, K), b(cx + 18, 60, cz - 26, cx + 24, 66, cz - 14, A)]
    elif kind == "transcendent":
        p += [b(cx - 8, 3, cz - 6, cx + 8, 20, cz + 6, G), b(cx - 11, 20, cz - 6, cx + 11, 40, cz + 6, G), b(cx - 5, 40, cz - 4, cx + 5, 50, cz + 4, G),
              b(cx - 3, 44, cz - 4.4, cx - 1, 46, cz - 4, A), b(cx + 1, 44, cz - 4.4, cx + 3, 46, cz - 4, A)]
        for i in range(4):
            p.append(b(cx - 20 + i * 11, 20, cz - 12 - i, cx - 19 + i * 11, 44, cz - 11 - i, A))
    elif kind == "king":
        p += [b(cx - 24, 3, cz - 20, cx + 24, 14, cz + 20, D), b(cx - 14, 14, cz - 10, cx + 14, 44, cz + 12, M), b(cx - 18, 44, cz - 8, cx + 18, 56, cz + 8, G),
              b(cx - 8, 56, cz - 7, cx + 8, 70, cz + 7, S), b(cx - 5, 62, cz - 7.4, cx - 2, 65, cz - 7, A), b(cx + 2, 62, cz - 7.4, cx + 5, 65, cz - 7, A),
              b(cx - 12, 70, cz - 9, cx + 12, 74, cz + 9, G), b(cx - 2, 74, cz - 2, cx + 2, 78, cz + 2, A), b(cx + 20, 0, cz - 2, cx + 23, 60, cz + 2, G),
              b(cx + 18, 58, cz - 4, cx + 25, 66, cz + 4, A), b(cx - 30, 14, cz - 4, cx - 24, 54, cz + 4, D), b(cx - 14, 14, cz + 12, cx + 14, 60, cz + 18, D)]
    return p


def walker_big(W, D_, H, gun=False, scorpion=False, cannon=False, triarch=False):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p = []
    for lx, lz in ((-0.34, -0.3), (0.34, -0.3), (-0.34, 0.3), (0.34, 0.3)):
        x, z = cx + lx * w, cz + lz * d
        p += [b(x - 3, 0, z - 3, x + 3, 5, z + 3, D), b(x - 2.4, 5, z - 2.4, x + 2.4, h * 0.38, z + 2.4, S), b(x - 3.4, h * 0.38, z - 3.4, x + 3.4, h * 0.38 + 5, z + 3.4, M)]
    p += [b(cx - w * 0.36, h * 0.38 + 4, cz - d * 0.38, cx + w * 0.36, h * 0.38 + 22, cz + d * 0.38, M), b(cx - w * 0.28, h * 0.38 + 22, cz - d * 0.3, cx + w * 0.28, h * 0.38 + 27, cz + d * 0.3, D),
          b(cx - 3, h * 0.38 + 8, cz - d * 0.38 - 0.4, cx + 3, h * 0.38 + 12, cz - d * 0.38, A)]
    if scorpion:
        p += [b(cx - 2, h * 0.38 + 14, cz + d * 0.2, cx + 2, h * 0.38 + 18, cz + d * 0.45, M), b(cx - 1.6, h * 0.38 + 18, cz + d * 0.3, cx + 1.6, h * 0.9, cz + d * 0.5 - 2, S),
              b(cx - 2.4, h * 0.9 - 1, cz + d * 0.5 - 6, cx + 2.4, h - 1, cz + d * 0.5 - 1, K), b(cx - 1, h * 0.9 - 0.5, cz + d * 0.5 - 7, cx + 1, h - 1.5, cz + d * 0.5 - 6, A)]
        for sx in (-1, 1):
            p += [b(cx + sx * w * 0.38 - 2, h * 0.38 + 6, cz - d * 0.5, cx + sx * w * 0.38 + 2, h * 0.38 + 12, cz - d * 0.3, W_), b(cx + sx * w * 0.38 - 1, h * 0.38 + 8, cz - d * 0.5 - 4, cx + sx * w * 0.38 + 1, h * 0.38 + 10, cz - d * 0.5, S)]
        if cannon:
            p += [b(cx - 3, h * 0.38 + 18, cz - d * 0.4, cx + 3, h * 0.38 + 23, cz + d * 0.1, K), b(cx - 1.4, h * 0.38 + 19, cz - d * 0.4 - 5, cx + 1.4, h * 0.38 + 22, cz - d * 0.4, A)]
    if gun:
        p += [b(cx - 4, h * 0.38 + 18, cz - d * 0.35, cx + 4, h * 0.38 + 24, cz + d * 0.15, K), b(cx - 1.6, h * 0.38 + 19.4, cz - d * 0.5, cx + 1.6, h * 0.38 + 22.6, cz - d * 0.35, S), b(cx - 1.6, h * 0.38 + 19.4, cz - d * 0.55, cx + 1.6, h * 0.38 + 22.6, cz - d * 0.5, A)]
        if triarch:
            p += [b(cx - 8, h * 0.38 + 18, cz - 2, cx - 4, h * 0.38 + 21, cz + 8, G), b(cx + 4, h * 0.38 + 18, cz - 2, cx + 8, h * 0.38 + 21, cz + 8, G)]
    return p


# ---------------- Imperial Knights ----------------
def arm(kind, side, w, d, h, y0):
    """Arm hanging at the side of a Knight; side=-1 left, +1 right. Returns parts."""
    cx, cz = w / 2, d / 2
    x = cx + side * 25
    top = y0
    p = [b(x - 4, top - 8, cz - 5, x + 4, top, cz + 5, M), b(x - 3, top - 22, cz - 4, x + 3, top - 8, cz + 4, S)]
    zf = cz - 5
    if kind in ("cannon", "autocannon", "bolt"):
        p += [b(x - 3.4, top - 30, zf - 18, x + 3.4, top - 22, cz + 6, K), b(x - 1.6, top - 28.4, zf - 30, x + 1.6, top - 24.8, zf - 18, S),
              b(x - 1.6, top - 28.4, zf - 31, x + 1.6, top - 24.8, zf - 30, A)]
    elif kind in ("thermal", "flame", "volkite", "decimator", "gatling"):
        n = 3 if kind == "gatling" else 1
        p += [b(x - 4, top - 32, zf - 8, x + 4, top - 22, cz + 6, K)]
        for i in range(n):
            ox = (i - (n - 1) / 2) * 3
            p += [b(x + ox - 1.2, top - 29, zf - 22, x + ox + 1.2, top - 26.6, zf - 8, S), b(x + ox - 1.2, top - 29, zf - 23, x + ox + 1.2, top - 26.6, zf - 22, A)]
        if kind == "decimator":
            p += [b(x - 3, top - 36, zf - 28, x + 3, top - 28, zf - 8, S)]
    elif kind in ("chainsword", "lascutter", "shocklance", "spear"):
        p += [b(x - 2, top - 26, zf - 28, x + 2, top - 20, cz + 4, S), b(x - 0.8, top - 25, zf - 29, x + 0.8, top - 21, zf - 28, W_),
              b(x - 3.4, top - 28, zf - 26, x + 3.4, top - 18, zf - 14, G)]
        if kind == "shocklance":
            p += [b(x - 1, top - 24, zf - 40, x + 1, top - 22, zf - 28, K), b(x - 2, top - 25, zf - 46, x + 2, top - 21, zf - 40, A)]
    elif kind in ("gauntlet", "claw", "harpoon"):
        p += [b(x - 5.6, top - 34, zf - 6, x + 5.6, top - 22, cz + 5, M), b(x - 6.6, top - 36, zf - 10, x + 6.6, top - 28, zf - 5, S), b(x - 6, top - 38, zf - 12, x + 6, top - 34, zf - 5, G)]
        if kind == "harpoon":
            p += [b(x - 1, top - 31, zf - 30, x + 1, top - 29, zf - 10, K), b(x - 2, top - 32, zf - 38, x + 2, top - 28, zf - 30, A)]
    elif kind == "shield_gun":
        p += [b(x - 1.2, top - 20, zf - 4, x + 1.2, top - 8, cz + 4, S), b(x - 1.5, top - 16, zf - 12, x + 1.5, top - 6, zf - 4, K)]
    elif kind == "laser":
        p += [b(x - 3, top - 28, zf - 12, x + 3, top - 22, cz + 6, K)] + [b(x - 1.4 + i * 2.2, top - 28, zf - 22, x - 0.6 + i * 2.2, top - 26.4, zf - 12, A) for i in range(3)]
    return p


def knight(W, D_, H, arm_l="chainsword", arm_r="cannon", carapace="pods", dominus=False, cerastus=False, hekaton=False,
           banner=False, light=False):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    s = 0.9 if light else 1.0
    k = h / 80.0
    pel = 42 * k
    p = []
    for sx in (-1, 1):
        X = cx + sx * 15
        # digitigrade leg: broad foot, back-slanted shin, forward knee guard, thigh back to the hip
        p += [b(X - 9, 0, cz - 9, X + 9, 5 * k, cz + 15, D), b(X - 8, 5 * k, cz - 11, X + 8, 9 * k, cz - 1, M), b(X - 6, 5 * k, cz + 8, X + 6, 12 * k, cz + 15, K),
              b(X - 5, 5 * k, cz + 1, X + 5, 14 * k, cz + 9, S),
              b(X - 5.6, 14 * k, cz + 5, X + 5.6, 24 * k, cz + 14, M), b(X - 4.4, 14 * k, cz + 14, X + 4.4, 22 * k, cz + 15.4, A),
              b(X - 6.6, 24 * k, cz + 1, X + 6.6, 33 * k, cz + 11, M),
              b(X - 8.4, 28 * k, cz - 9, X + 8.4, 37 * k, cz + 2, D), b(X - 5.4, 29.5 * k, cz - 10.4, X + 5.4, 35.5 * k, cz - 9, G),
              b(X - 7.4, 34 * k, cz - 4, X + 7.4, 46 * k, cz + 11, M), b(X - 6, 40 * k, cz + 11, X + 6, 46 * k, cz + 13, S),
              b(X - 7.8, 38 * k, cz - 3, X - 6.6, 45 * k, cz + 10, D), b(X + 6.6, 38 * k, cz - 3, X + 7.8, 45 * k, cz + 10, D)]
    p += [b(cx - 24, pel, cz - 8, cx + 24, pel + 8 * k, cz + 12, D),
          b(cx - 29, pel - 4 * k, cz - 9, cx - 20, pel + 8 * k, cz + 11, M), b(cx + 20, pel - 4 * k, cz - 9, cx + 29, pel + 8 * k, cz + 11, M),
          b(cx - 8, pel - 6 * k, cz - 11, cx + 8, pel + 6 * k, cz - 8, M), b(cx - 3, pel - 3 * k, cz - 11.8, cx + 3, pel + 3 * k, cz - 11, A)]
    tor_w = 17 if not dominus else 20
    tw = tor_w + 4
    p += [b(cx - tw + 3, pel + 8 * k, cz - 9, cx + tw - 3, pel + 12 * k, cz + 11, K),
          b(cx - tw, pel + 12 * k, cz - 12, cx + tw, pel + 26 * k, cz + 14, M),
          b(cx - tw + 4, pel + 14 * k, cz - 13.4, cx + tw - 4, pel + 24 * k, cz - 12, D),
          b(cx - tw + 6, pel + 16 * k, cz - 14, cx + tw - 6, pel + 22 * k, cz - 13.4, G),
          b(cx - 5, pel + 17 * k, cz - 14.6, cx + 5, pel + 21 * k, cz - 14, A),
          b(cx - tw - 1, pel + 24 * k, cz - 8, cx + tw + 1, pel + 29 * k, cz + 12, D),
          b(cx - 8, pel + 12 * k, cz + 14, cx + 8, pel + 26 * k, cz + 19, K), b(cx - 5, pel + 16 * k, cz + 19, cx + 5, pel + 22 * k, cz + 20, A)]
    hy = pel + 28 * k
    p += [b(cx - 7, hy, cz - 7, cx + 7, hy + 8 * k, cz + 6, S), b(cx - 5, hy + 3 * k, cz - 8.4, cx + 5, hy + 6 * k, cz - 7, A),
          b(cx - 8, hy + 7 * k, cz - 5, cx + 8, hy + 9 * k, cz + 5, G), b(cx - 2.4, hy + 9 * k, cz - 4, cx + 2.4, hy + 12 * k, cz + 2, M),
          b(cx - 0.8, hy + 12 * k, cz - 4, cx + 0.8, hy + 15 * k, cz + 1, K)]
    if cerastus:
        p += [b(cx - 9, hy + 6, cz - 3, cx + 9, hy + 14, cz + 3, D), b(cx - 5, hy + 14, cz - 2, cx + 5, hy + 18, cz + 2, G)]
    # shoulder armour + ion shield
    for sx in (-1, 1):
        x = cx + sx * (tor_w + 2)
        p += [b(x - 5, pel + 22 * k, cz - 10, x + 5, pel + 31 * k, cz + 11, D), b(x - 6, pel + 26 * k, cz - 9, x + 6, pel + 30 * k, cz + 10, M), b(x - 4, pel + 31 * k, cz - 6, x + 4, pel + 33 * k, cz + 7, G)]
    p += [b(cx - tor_w - 9, pel + 6, cz - 10, cx - tor_w - 6, pel + 32, cz + 8, M), b(cx - tor_w - 9.6, pel + 10, cz - 11, cx - tor_w - 6, pel + 28, cz - 10, G)] if (arm_l in ("shield_gun",) or dominus) else []
    # arms
    p += arm(arm_l, -1, w, d, h, pel + 26 * k) if not hekaton else arm("claw", -1, w, d, h, pel + 26 * k)
    p += arm(arm_r, 1, w, d, h, pel + 26 * k)
    # carapace
    if carapace == "pods":
        for sx in (-1, 1):
            x = cx + sx * (tor_w * 0.55)
            p += [b(x - 4, pel + 29, cz - 2, x + 4, pel + 36, cz + 10, K), b(x - 3, pel + 33, cz - 8, x + 3, pel + 36, cz - 2, S), b(x - 2, pel + 36, cz - 4, x + 2, pel + 37, cz + 6, A)]
    elif carapace == "missiles":
        for sx in (-1, 1):
            x = cx + sx * (tor_w * 0.6)
            p += [b(x - 5, pel + 30, cz - 4, x + 5, pel + 38, cz + 12, K), b(x - 1.4, pel + 33, cz - 12, x + 1.4, pel + 36, cz - 4, S), b(x - 1.4, pel + 33, cz - 13, x + 1.4, pel + 36, cz - 12, A)]
    # lower skirt / heraldry
    if banner:
        p += [b(cx + tor_w - 4, pel + 32, cz + 10, cx + tor_w - 3, h - 2, cz + 11, K), b(cx + tor_w - 14, h - 22, cz + 10.4, cx + tor_w - 3.4, h - 4, cz + 10.9, A)]
    return p


def armiger(W, D_, H, arm_l="autocannon", arm_r="autocannon"):
    """A smaller Knight: same detailed body built at Knight size, then scaled to the Armiger base."""
    w, d, h = W * 16, D_ * 16, H * 16
    big = knight(6, 6, 5, arm_l=arm_l, arm_r=arm_r, carapace="none", light=True)
    f = min(w / 96.0, d / 96.0, h / 80.0) * 0.98
    return sc(big, f, (w - 96 * f) / 2, 0, (d - 96 * f) / 2)


def acastus(W, D_, H, twin_beam=True):
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p = []
    for sx in (-1, 1):
        x = cx + sx * w * 0.30
        p += [b(x - 9, 0, cz - 8, x + 9, 8, cz + 18, D), b(x - 6, 8, cz - 2, x + 6, h * 0.32, cz + 12, S), b(x - 8, h * 0.32, cz - 6, x + 8, h * 0.32 + 10, cz + 14, M),
              b(x - 6, h * 0.32 + 10, cz - 2, x + 6, h * 0.5, cz + 12, S)]
    pel = h * 0.5
    p += [b(cx - 26, pel, cz - 10, cx + 26, pel + 10, cz + 18, D), b(cx - 24, pel + 10, cz - 14, cx + 24, pel + 34, cz + 20, M),
          b(cx - 10, pel + 16, cz - 15, cx + 10, pel + 26, cz - 14, A), b(cx - 10, pel + 34, cz - 8, cx + 10, pel + 46, cz + 6, S), b(cx - 6, pel + 38, cz - 9, cx + 6, pel + 42, cz - 8, A),
          b(cx - 2, pel + 46, cz - 4, cx + 2, pel + 52, cz + 2, G)]
    for sx in (-1, 1):
        x = cx + sx * 30
        p += [b(x - 7, pel + 20, cz - 14, x + 7, pel + 40, cz + 14, D)]
        gx = cx + sx * 14
        if twin_beam:
            p += [b(gx - 5, pel + 36, cz - 8, gx + 5, pel + 46, cz + 24, K), b(gx - 3, pel + 38, cz - 30, gx - 0.4, pel + 44, cz - 8, S), b(gx + 0.4, pel + 38, cz - 30, gx + 3, pel + 44, cz - 8, S),
                  b(gx - 3, pel + 38, cz - 31, gx - 0.4, pel + 44, cz - 30, A), b(gx + 0.4, pel + 38, cz - 31, gx + 3, pel + 44, cz - 30, A)]
        else:
            p += [b(gx - 5, pel + 36, cz - 8, gx + 5, pel + 46, cz + 24, K), b(gx - 3.4, pel + 39, cz - 34, gx + 3.4, pel + 44, cz - 8, S), b(gx - 3.4, pel + 39, cz - 35, gx + 3.4, pel + 44, cz - 34, A)]
    p += [b(cx - 44, pel + 8, cz - 8, cx - 34, pel + 22, cz + 4, S), b(cx - 45, pel + 8, cz - 22, cx - 41, pel + 16, cz - 8, K)]
    return p


def skitarii(weapon="rifle", noble=False, fly=False, **kw):
    return hum(weapon=weapon, robe=True, noble=noble, fly=fly)


# ---------------- Adeptus Mechanicus ----------------
def cog(cx, cy, cz, r, slot=None, t=0.7):
    """Gear ring in the x/y plane (facing +-z) made of 8 small boxes."""
    slot = G if slot is None else slot
    out = []
    for i in range(8):
        a = i * math.pi / 4
        x, y = cx + r * math.cos(a), cy + r * math.sin(a)
        out.append(b(x - 0.7, y - 0.7, cz, x + 0.7, y + 0.7, cz + t, slot))
    return out


def techpriest(kind="dominus"):
    wp = {"dominus": "staff", "enginseer": "blade", "manipulus": "staff", "techno": "pistol"}[kind]
    p = hum(weapon=wp, robe=True)
    p += cog(8, 12.5, 10.6, 3.6)
    p += [b(7.2, 11.7, 10.4, 8.8, 13.3, 11.4, A)]
    if kind == "dominus":
        p += [b(4.6, 8, 10, 5.6, 15, 11.2, S), b(10.4, 8, 10, 11.4, 15, 11.2, S), b(3.8, 14.4, 9.6, 5.6, 15.4, 11.4, G), b(10.4, 14.4, 9.6, 12.2, 15.4, 11.4, G)]
    elif kind == "enginseer":
        p += [b(3.0, 7.5, 7, 4.4, 9, 12, S), b(2.6, 6.8, 11.4, 4.4, 8, 13, K), b(11.6, 8, 8, 12.6, 9.2, 13, S)]
    elif kind == "manipulus":
        p += [b(3.2, 10.5, 9.4, 4.2, 16, 10.4, S), b(11.8, 10.5, 9.4, 12.8, 16, 10.4, S), b(10.6, 8.4, 0.5, 12.0, 9.6, 8.5, K), b(10.9, 8.6, 0, 11.7, 9.4, 0.5, A)]
    else:
        p += [b(11.4, 8.2, 8, 12.8, 9.4, 12, S), b(2.8, 9, 7.4, 4.2, 10, 11, S), b(12, 12.6, 5.8, 13.4, 14, 7.4, A)]
    return p


def kataphron(W, D_, H, kind="breacher"):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - 10, 0, cz - 10, cx - 5, 3.4, cz + 10, K), b(cx + 5, 0, cz - 10, cx + 10, 3.4, cz + 10, K),
         b(cx - 9.6, 3.4, cz - 9, cx - 5.4, 4.2, cz + 9, S), b(cx + 5.4, 3.4, cz - 9, cx + 9.6, 4.2, cz + 9, S),
         b(cx - 8, 4, cz - 8, cx + 8, 11, cz + 8, M), b(cx - 6, 11, cz - 5, cx + 6, 20, cz + 5, D),
         b(cx - 3, 20, cz - 3.4, cx + 3, 25, cz + 2.6, S), b(cx - 2, 22, cz - 3.8, cx - 0.6, 23.4, cz - 3.4, A), b(cx + 0.6, 22, cz - 3.8, cx + 2, 23.4, cz - 3.4, A),
         b(cx - 6, 11, cz + 5, cx + 6, 22, cz + 9, D)]
    p += cog(cx, 17, cz + 9, 3.2)
    if kind == "breacher":
        p += [b(cx - 13, 11, cz - 10, cx - 8, 18, cz + 4, K), b(cx - 12, 12.4, cz - 19, cx - 9, 15.6, cz - 10, S), b(cx - 11.6, 12.8, cz - 19.6, cx - 9.4, 15.2, cz - 19, A),
              b(cx + 8, 9, cz - 9, cx + 13, 20, cz, S), b(cx + 8.4, 8, cz - 13, cx + 9.4, 12, cz - 9, W_), b(cx + 11, 8, cz - 13, cx + 12, 12, cz - 9, W_)]
    else:
        p += [b(cx + 8, 14, cz - 14, cx + 13, 19.5, cz + 2, K), b(cx + 9, 15, cz - 17, cx + 12, 18.5, cz - 14, A),
              b(cx - 13, 10, cz - 10, cx - 8, 16, cz, S), b(cx - 12, 11, cz - 15, cx - 9, 14, cz - 10, K), b(cx - 11.4, 11.4, cz - 16, cx - 9.6, 13.6, cz - 15, A)]
    return p


def serberys(W, D_, H, hound=False):
    cx = W * 8
    p = []
    for x in (cx - 3, cx + 3):
        for z in (9, 23):
            p += [b(x - 1, 0, z - 1, x + 1, 4, z + 1, S), b(x - 1.4, 3, z - 1.4, x + 1.4, 5.2, z + 1.4, D)]
    p += [b(cx - 4.6, 4.6, 7, cx + 4.6, 8.4, 26, M), b(cx - 3.4, 8.4, 9, cx + 3.4, 9, 24, D),
          b(cx - 2.6, 5, 2, cx + 2.6, 9.4, 7.4, S), b(cx - 1.8, 6.6, 1.2, cx + 1.8, 8, 2, K), b(cx - 1.8, 7.8, 1.6, cx - 0.8, 8.8, 2.2, A), b(cx + 0.8, 7.8, 1.6, cx + 1.8, 8.8, 2.2, A),
          b(cx - 0.8, 6.6, 26, cx + 0.8, 8.2, 30, S)]
    if hound:
        p += [b(cx - 3, 8.4, 12, cx + 3, 11.4, 20, K), b(cx - 1, 11.4, 14, cx + 1, 12.6, 18, A), b(cx - 1.2, 6.2, 0, cx + 1.2, 7, 1.4, A)]
    else:
        p += sc(hum(weapon="rifle", robe=True), 0.5, cx - 4, 8.4, 12)
    return p


def ironstrider(W, D_, H, kind="ballistarii"):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = []
    for sx in (-1, 1):
        x = cx + sx * 11
        p += [b(x - 2, 24, cz + 1, x + 2, 36, cz + 7, S), b(x - 1.7, 12, cz - 6, x + 1.7, 25, cz + 2, D), b(x - 1.7, 3, cz - 11, x + 1.7, 13, cz - 5, S),
              b(x - 3.4, 0, cz - 14, x + 3.4, 2.4, cz - 4, K), b(x - 2.6, 2.4, cz - 12, x + 2.6, 4, cz - 6, D)]
    p += [b(cx - 12, 32, cz - 8, cx + 12, 42, cz + 12, M), b(cx - 5, 35, cz - 9, cx + 5, 40, cz - 8, A), b(cx - 8, 42, cz - 5, cx + 8, 45, cz + 8, D),
          b(cx - 3, 45, cz - 2, cx + 3, 47, cz + 3, S), b(cx - 6, 33, cz + 12, cx + 6, 41, cz + 16, D)]
    p += cog(cx, 37, cz + 16, 2.8)
    if kind == "ballistarii":
        p += [b(cx - 10, 33, cz - 10, cx - 4, 38, cz - 4, K), b(cx - 9, 34, cz - 24, cx - 5, 37, cz - 10, S), b(cx - 8.6, 34.4, cz - 25, cx - 5.4, 36.6, cz - 24, A),
              b(cx + 4, 33, cz - 10, cx + 10, 38, cz - 4, K), b(cx + 5, 34, cz - 24, cx + 9, 37, cz - 10, S), b(cx + 5.4, 34.4, cz - 25, cx + 8.6, 36.6, cz - 24, A)]
    elif kind == "jezzail":
        p += [b(cx + 8, 35, cz - 24, cx + 10, 37, cz - 8, K), b(cx + 8.4, 35.4, cz - 26, cx + 9.6, 36.6, cz - 24, A), b(cx + 7, 34, cz - 8, cx + 11, 39, cz, D),
              b(cx - 10, 35, cz - 12, cx - 7, 37, cz - 4, S)]
    else:
        p += [b(cx + 12, 34, cz - 22, cx + 14, 36, cz + 4, G), b(cx + 11.4, 33.4, cz - 26, cx + 14.6, 36.6, cz - 22, A), b(cx + 10.6, 33, cz - 4, cx + 14.6, 37, cz + 2, S)]
    return p


def archmagos(W, D_, H, ghuld=False):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = []
    for lx, lz in ((-0.34, -0.3), (0.34, -0.3), (-0.34, 0.3), (0.34, 0.3)):
        x, z = cx + lx * w, cz + lz * d
        p += [b(x - 2.4, 0, z - 2.4, x + 2.4, 3, z + 2.4, D), b(x - 1.6, 3, z - 1.6, x + 1.6, 12, z + 1.6, S)]
    p += [b(cx - w * 0.3, 11, cz - d * 0.28, cx + w * 0.3, 17, cz + d * 0.28, M), b(cx - w * 0.22, 17, cz - d * 0.2, cx + w * 0.22, 19, cz + d * 0.2, D)]
    f = 2.1 if ghuld else 2.0
    p += sc(hum(weapon="rod" if ghuld else "blade", robe=True, crown=True), f, cx - 8 * f, 19, cz - 8 * f)
    p += cog(cx, 38, cz + 9, 7.5, t=1.0)
    for i in range(-2, 2):
        x = cx + i * 4 + 2
        p += [b(x - 0.8, 24, cz + 8, x + 0.8, 44 + (i % 2) * 2, cz + 10, S), b(x - 1.2, 44 + (i % 2) * 2, cz + 7.8, x + 1.2, 46 + (i % 2) * 2, cz + 10.4, A)]
    if ghuld:
        p += [b(cx + 9, 24, cz - 20, cx + 14, 32, cz + 2, K), b(cx + 9.6, 25, cz - 23, cx + 13.4, 31, cz - 20, A)]
    else:
        p += [b(cx - 15, 26, cz - 14, cx - 10, 32, cz + 1, K), b(cx - 14, 27, cz - 18, cx - 11, 31, cz - 14, A), b(cx - 14, 20, cz - 6, cx - 11, 26, cz + 4, S)]
    return p


def skorpius(W, D_, H, kind="dune"):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - 18, 3, 6, cx + 18, 8, d - 6, D), b(cx - 17, 8, 10, cx + 17, 24, d - 8, M), b(cx - 14, 8, 3, cx + 14, 18, 10, M), b(cx - 11, 10, 1, cx + 11, 14, 3, S),
         b(cx - 13, 24, 14, cx + 13, 33, 46, D), b(cx - 11, 26, 12, cx + 11, 31, 14, A), b(cx - 15, 24, 50, cx + 15, 30, d - 12, M),
         b(cx - 20, 4, 12, cx - 18, 9, 34, A), b(cx + 18, 4, 12, cx + 20, 9, 34, A), b(cx - 20, 4, 60, cx - 18, 9, 82, A), b(cx + 18, 4, 60, cx + 20, 9, 82, A)]
    p += cog(cx, 20, d - 8.2, 5.5, t=0.8)
    if kind == "dune":
        p += [b(cx - 8, 10, d - 8, cx + 8, 22, d - 4, S), b(cx - 6, 33, 22, cx + 6, 38, 34, K), b(cx - 4.4, 34.4, 8, cx - 2.2, 36.6, 22, S), b(cx + 2.2, 34.4, 8, cx + 4.4, 36.6, 22, S),
              b(cx - 4, 34.6, 6, cx - 2.6, 36.4, 8, A), b(cx + 2.6, 34.6, 6, cx + 4, 36.4, 8, A), b(cx - 8, 30, 60, cx + 8, 34, 80, D)]
    else:
        p += [b(cx - 8, 33, 30, cx + 8, 42, 62, K), b(cx - 3.4, 35.6, 1, cx + 3.4, 40.4, 30, S), b(cx - 4, 35, 0, cx + 4, 41, 1.4, A),
              b(cx - 16, 24, 20, cx - 12, 29, 34, K), b(cx + 12, 24, 20, cx + 16, 29, 34, K), b(cx - 8, 30, 62, cx + 8, 34, 82, D)]
    return p


def termite(W, D_, H):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - 24, 6, 16, cx + 24, 36, d - 6, M), b(cx - 28, 0, 20, cx - 21, 11, d - 8, K), b(cx + 21, 0, 20, cx + 28, 11, d - 8, K),
         b(cx - 10, 36, 30, cx + 10, 40, d - 12, D), b(cx - 6, 40, 52, cx + 6, 48, 64, D), b(cx - 1.5, 42, 38, cx + 1.5, 45, 52, K), b(cx - 1.5, 41.6, 36.6, cx + 1.5, 45.4, 38, A)]
    for z0, hw in ((0, 4), (3, 7.5), (6, 11), (9, 14.5), (12, 18)):
        p.append(b(cx - hw, 21 - hw, z0, cx + hw, 21 + hw, z0 + 4, S if z0 else A))
    p += [b(cx - 24, 36, 18, cx - 21, 42, 28, K), b(cx + 21, 36, 18, cx + 24, 42, 28, K), b(cx - 8, 10, d - 6, cx + 8, 32, d - 4, S)]
    p += cog(cx, 22, d - 6.2, 8, t=0.8)
    return p


def archaeopter(W, D_, H, kind="fusilave"):
    w, d = W * 16, D_ * 16
    cx, cz = w / 2, d / 2
    p = [b(cx - 2, 0, cz - 2, cx + 2, 24, cz + 2, K), b(cx - 7, 0, cz - 7, cx + 7, 1, cz + 7, K),
         b(cx - 10, 24, 6, cx + 10, 38, 58, M), b(cx - 6, 26, 1, cx + 6, 34, 6, S), b(cx - 5, 34, 7, cx + 5, 40, 17, A), b(cx - 8, 38, 20, cx + 8, 41, 50, D),
         b(cx - 8, 28, 56, cx + 8, 36, 62, D)]
    p += [b(cx - 44, 28, 24, cx - 10, 32, 42, D), b(cx + 10, 28, 24, cx + 44, 32, 42, D), b(cx - 48, 27, 26, cx - 44, 33, 40, M), b(cx + 44, 27, 26, cx + 48, 33, 40, M)]
    p += cog(cx, 31, 58.4, 4.4, t=0.8)
    if kind == "transvector":
        p += [b(cx - 12, 20, 14, cx + 12, 24, 52, D), b(cx - 28, 44, cz - 1, cx + 28, 45, cz + 1, S), b(cx - 1, 44, cz - 28, cx + 1, 45, cz + 28, S), b(cx - 2, 40, cz - 2, cx + 2, 44, cz + 2, G),
              b(cx - 6, 26, 0, cx + 6, 30, 2, K)]
    else:
        p += [b(cx - 18, 26, 40, cx - 12, 34, 60, S), b(cx + 12, 26, 40, cx + 18, 34, 60, S), b(cx - 17, 28, 60, cx - 13, 32, 61, A), b(cx + 13, 28, 60, cx + 17, 32, 61, A)]
        if kind == "fusilave":
            p += [b(cx - 34, 24, 26, cx - 28, 28, 38, K), b(cx + 28, 24, 26, cx + 34, 28, 38, K), b(cx - 20, 22, 26, cx - 16, 26, 38, W_), b(cx + 16, 22, 26, cx + 20, 26, 38, W_)]
        else:
            p += [b(cx - 3, 22, 4, cx + 3, 26, 36, K), b(cx - 1.4, 23, 0, cx + 1.4, 25, 4, A), b(cx - 30, 24, 20, cx - 26, 28, 36, K), b(cx + 26, 24, 20, cx + 30, 28, 36, K)]
    return p


def onager(W, D_, H):
    p = walker_big(W, D_, H, gun=True)
    w, d, h = W * 16, D_ * 16, H * 16
    cx, cz = w / 2, d / 2
    p += [b(cx - w * 0.3, 6, cz - d * 0.3, cx + w * 0.3, h * 0.38 + 4, cz + d * 0.3, D), b(cx - w * 0.34, 14, cz - d * 0.34, cx + w * 0.34, h * 0.38, cz + d * 0.34, M)]
    p += [b(cx - 9, h * 0.38 + 27, cz - 9, cx + 9, h * 0.38 + 31, cz + 9, L), b(cx - 5, h * 0.38 + 31, cz - 5, cx + 5, h * 0.38 + 35, cz + 5, A)]
    p += cog(cx, h * 0.38 + 14, cz + d * 0.38 + 0.4, 6, t=0.8)
    return p


def build(u):
    W, D_, H = u["dims"]
    c = u["cls"]
    pr = dict(u["params"])
    if c == "humanoid":
        f = pr.pop("scale", 1.0)
        pr.pop("tint", None)
        if W == 1 and f == 1.0:
            p = hum(**pr)
        else:
            p = hum_scaled(f, W, D_, **pr)
    elif c == "skitarii":
        p = skitarii(**pr)
    elif c == "serpent":
        p = serpent(W, D_, H, **pr)
    elif c == "crawler":
        p = crawler(W, D_, H, **pr)
    elif c == "swarm":
        p = swarm(W, D_, H)
    elif c == "drone":
        p = drone(W, D_, H)
    elif c == "blade":
        p = blade(W, D_, H)
    elif c == "lokhust":
        p = lokhust(W, D_, H, **pr)
    elif c == "barge":
        p = barge(W, D_, H, **pr)
    elif c == "ark":
        p = ark(W, D_, H, **pr)
    elif c == "scythe":
        p = scythe(W, D_, H, **pr)
    elif c == "monolith":
        p = monolith(W, D_, H)
    elif c == "obelisk":
        p = obelisk(W, D_, H)
    elif c == "vault":
        p = vault(W, D_, H)
    elif c == "construct":
        p = construct(W, D_, H)
    elif c == "pylon":
        p = pylon(W, D_, H, **pr)
    elif c == "pylon_small":
        p = pylon_small(W, D_, H)
    elif c == "walls":
        p = walls(W, D_, H)
    elif c == "ctan":
        p = ctan(W, D_, H, **pr)
    elif c == "walker_big":
        p = walker_big(W, D_, H, **pr)
    elif c == "knight":
        p = knight(W, D_, H, **pr)
    elif c == "armiger":
        p = armiger(W, D_, H, **pr)
    elif c == "acastus":
        p = acastus(W, D_, H, **pr)
    elif c == "techpriest":
        p = techpriest(**pr)
    elif c == "kataphron":
        p = kataphron(W, D_, H, **pr)
    elif c == "serberys":
        p = serberys(W, D_, H, **pr)
    elif c == "ironstrider":
        p = ironstrider(W, D_, H, **pr)
    elif c == "archmagos":
        p = archmagos(W, D_, H, **pr)
    elif c == "skorpius":
        p = skorpius(W, D_, H, **pr)
    elif c == "termite":
        p = termite(W, D_, H)
    elif c == "archaeopter":
        p = archaeopter(W, D_, H, **pr)
    elif c == "onager":
        p = onager(W, D_, H)
    else:
        raise ValueError(c)
    q = symmetrize(clip(p, W, D_, H), u)
    if W * D_ * H > 1 and u["cls"] not in ("swarm", "walls", "ironstrider", "kataphron", "archmagos", "serberys"):
        q = clip(greeble(q, u), W, D_, H)
    return q


SYM_FILL = 0.88  # share of the base the model should fill after being made symmetric


def symmetrize(parts, u):
    """Big models: equal length and width (stretch the shorter side), centred on the base, scaled to fill it."""
    W, D_, H = u["dims"]
    if W != D_ or W == 1 or u["cls"] in ("walls",) or not parts:
        return parts
    x0 = min(p[0] for p in parts); x1 = max(p[3] for p in parts)
    z0 = min(p[2] for p in parts); z1 = max(p[5] for p in parts)
    ymax = max(p[4] for p in parts)
    span = max(x1 - x0, z1 - z0)
    target = W * 16.0 * SYM_FILL
    f = target / span              # uniform growth/shrink of the footprint
    sx = f * span / max(x1 - x0, 0.01)
    sz = f * span / max(z1 - z0, 0.01)
    fy = min(math.sqrt(sx * sz), (H * 16.0 - 0.5) / ymax)
    fy = max(fy, 0.6)
    cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
    mid = W * 16.0 / 2
    out = []
    for a, b, c, d, e, g, s in parts:
        out.append([mid + (a - cx) * sx, b * fy, mid + (c - cz) * sz, mid + (d - cx) * sx, e * fy, mid + (g - cz) * sz, s])
    return clip(out, W, D_, H)


def greeble(parts, u, seed=3):
    """Detail pass for big models: raised panels with a border, vents, rivets and (Necrons) glowing seams on every large armour face."""
    rnd = random.Random(seed + len(parts))
    necron = u["fac"] == "necrons"
    out = list(parts)
    for x1, y1, z1, x2, y2, z2, s in parts:
        if s not in (M, D, S):
            continue
        dx, dy, dz = x2 - x1, y2 - y1, z2 - z1
        plate = (D if s in (M, S) else (S if necron else M))
        t = 0.35
        # top plate with vents
        if dx >= 5 and dz >= 5:
            out.append([x1 + 1.0, y2, z1 + 1.0, x2 - 1.0, y2 + t, z2 - 1.0, plate])
            if s == M and dx >= 9 and dz >= 9:
                n = int((dz - 3) // 2)
                for i in range(n):
                    zz = z1 + 2.0 + i * 2.0
                    out.append([x1 + 2.0, y2 + t, zz, x2 - 2.0, y2 + t + 0.25, zz + 0.7, K])
            if necron:
                out.append([(x1 + x2) / 2 - 0.4, y2 + t, z1 + 1.6, (x1 + x2) / 2 + 0.4, y2 + t + 0.2, z2 - 1.6, A])
        # side plates (front/back = +-z, left/right = +-x)
        if dx >= 5 and dy >= 4:
            for zz, zo in ((z1 - t, z1), (z2, z2 + t)):
                out.append([x1 + 1.0, y1 + 1.0, min(zz, zo), x2 - 1.0, y2 - 1.0, max(zz, zo), plate])
                if necron and dy >= 5:
                    zz2 = z1 - t - 0.15 if zz < z1 else z2 + t
                    out.append([x1 + 1.6, (y1 + y2) / 2 - 0.35, zz2, x2 - 1.6, (y1 + y2) / 2 + 0.35, zz2 + 0.15, A])
                elif not necron and dy >= 5:
                    for rx in (x1 + 1.3, x2 - 1.9):
                        zz2 = z1 - t - 0.3 if zz < z1 else z2 + t
                        out.append([rx, y2 - 2.3, zz2, rx + 0.6, y2 - 1.7, zz2 + 0.3, G])
        if dz >= 5 and dy >= 4:
            for xx, xo in ((x1 - t, x1), (x2, x2 + t)):
                out.append([min(xx, xo), y1 + 1.0, z1 + 1.0, max(xx, xo), y2 - 1.0, z2 - 1.0, plate])
                if necron and dy >= 5:
                    xx2 = x1 - t - 0.15 if xx < x1 else x2 + t
                    out.append([xx2, (y1 + y2) / 2 - 0.35, z1 + 1.6, xx2 + 0.15, (y1 + y2) / 2 + 0.35, z2 - 1.6, A])
        # rivets on big flat plates
        if dx >= 8 and dz >= 8:
            for _ in range(4):
                rx, rz = rnd.uniform(x1 + 1.5, x2 - 2), rnd.uniform(z1 + 1.5, z2 - 2)
                out.append([rx, y2 + t, rz, rx + 0.5, y2 + t + 0.3, rz + 0.5, S if necron else G])
    return out


def clip(parts, W, D_, H):
    out = []
    mx, my, mz = W * 16.0, H * 16.0, D_ * 16.0
    for x1, y1, z1, x2, y2, z2, s in parts:
        x1, x2 = max(0.0, min(mx, x1)), max(0.0, min(mx, x2))
        y1, y2 = max(0.0, min(my, y1)), max(0.0, min(my, y2))
        z1, z2 = max(0.0, min(mz, z1)), max(0.0, min(mz, z2))
        if x2 - x1 > 0.05 and y2 - y1 > 0.05 and z2 - z1 > 0.05:
            out.append([round(x1, 3), round(y1, 3), round(z1, 3), round(x2, 3), round(y2, 3), round(z2, 3), s])
    return out

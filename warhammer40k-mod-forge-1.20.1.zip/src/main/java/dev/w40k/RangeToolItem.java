package dev.w40k;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** Movement (kind 0) and Attack (kind 1) tools: right-click a miniature to draw its range zone. */
public class RangeToolItem extends Item {
    public static final int MOVE = 0, ATTACK = 1;
    private static final int GREEN = 0x3CDC5A, YELLOW = 0xFFD83A, ORANGE = 0xFF8C1A, RED = 0xE62828;
    private final int kind;

    public RangeToolItem(Properties properties, int kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false; // left-click must not break the miniature
    }

    private record Mode(Component label, List<ZoneManager.Ring> rings) {}

    private List<Mode> modes(UnitData.Unit u, Component name) {
        List<Mode> out = new ArrayList<>();
        String id = W40kMod.MODID;
        if (kind == MOVE) {
            if (u.move() > 0) {
                out.add(new Mode(Component.translatable("msg." + id + ".move.normal", name, u.move()),
                        List.of(new ZoneManager.Ring(u.move(), GREEN))));
                out.add(new Mode(Component.translatable("msg." + id + ".move.advance", name, u.move(), u.move() + 6),
                        List.of(new ZoneManager.Ring(u.move(), GREEN), new ZoneManager.Ring(u.move() + 6, YELLOW))));
            }
            out.add(new Mode(Component.translatable("msg." + id + ".move.charge", name), List.of(new ZoneManager.Ring(12, ORANGE))));
        } else {
            for (UnitData.Weapon w : u.weapons()) {
                if (w.range() == 0) {
                    out.add(new Mode(Component.translatable("msg." + id + ".attack.melee", name, w.names()),
                            List.of(new ZoneManager.Ring(2, RED))));
                } else if (w.half()) {
                    int half = (w.range() + 1) / 2;
                    out.add(new Mode(Component.translatable("msg." + id + ".attack.half", name, w.names(), w.range(), half),
                            List.of(new ZoneManager.Ring(w.range(), RED), new ZoneManager.Ring(half, YELLOW))));
                } else {
                    out.add(new Mode(Component.translatable("msg." + id + ".attack.ranged", name, w.names(), w.range()),
                            List.of(new ZoneManager.Ring(w.range(), RED))));
                }
            }
        }
        return out;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        Level level = context.getLevel();
        if (player == null) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (!(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel sl)) {
            return InteractionResult.PASS;
        }
        if (player.isShiftKeyDown()) {
            ZoneManager.clear(sp);
            player.displayClientMessage(Component.translatable("msg." + W40kMod.MODID + ".range.cleared"), true);
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        UnitData.Unit unit = key != null && key.getNamespace().equals(W40kMod.MODID) ? UnitData.find(key.getPath()) : null;
        if (unit == null) {
            player.displayClientMessage(Component.translatable("msg." + W40kMod.MODID + ".range.notunit").withStyle(ChatFormatting.RED), true);
            return InteractionResult.SUCCESS;
        }
        BlockPos master = pos;
        double[] rect;
        if (state.getBlock() instanceof BigUnitBlock big) {
            master = big.masterOf(pos, state);
            Direction f = state.getValue(BigUnitBlock.FACING);
            int[][] corners = {{0, 0}, {big.w - 1, 0}, {0, big.d - 1}, {big.w - 1, big.d - 1}};
            int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
            for (int[] c : corners) {
                BlockPos r = BigUnitBlock.rotate(f, c[0], c[1]);
                minX = Math.min(minX, master.getX() + r.getX());
                maxX = Math.max(maxX, master.getX() + r.getX());
                minZ = Math.min(minZ, master.getZ() + r.getZ());
                maxZ = Math.max(maxZ, master.getZ() + r.getZ());
            }
            rect = new double[]{minX, minZ, maxX + 1, maxZ + 1};
        } else {
            rect = new double[]{pos.getX(), pos.getZ(), pos.getX() + 1, pos.getZ() + 1};
        }
        Component name = state.getBlock().getName();
        List<Mode> modes = modes(unit, name);
        if (modes.isEmpty()) {
            String key2 = kind == MOVE ? "immobile" : "noweapons";
            player.displayClientMessage(Component.translatable("msg." + W40kMod.MODID + ".range." + key2, name).withStyle(ChatFormatting.RED), true);
            return InteractionResult.SUCCESS;
        }
        ZoneManager.Zone old = ZoneManager.get(sp);
        int mode = 0;
        if (old != null && old.unitId().equals(unit.id()) && old.kind() == kind && old.master().equals(master)) {
            mode = (old.mode() + 1) % modes.size();
        }
        Mode m = modes.get(mode);
        ZoneManager.show(sp, sl, unit.id(), kind, mode, master, rect, m.rings());
        player.displayClientMessage(m.label().copy().withStyle(kind == MOVE ? ChatFormatting.GREEN : ChatFormatting.RED), true);
        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown() && !level.isClientSide && player instanceof ServerPlayer sp) {
            ZoneManager.clear(sp);
            player.displayClientMessage(Component.translatable("msg." + W40kMod.MODID + ".range.cleared"), true);
            return InteractionResultHolder.sidedSuccess(stack, false);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        String base = "tooltip." + W40kMod.MODID + (kind == MOVE ? ".move_tool." : ".attack_tool.");
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable(base + i).withStyle(ChatFormatting.GRAY));
        }
    }
}

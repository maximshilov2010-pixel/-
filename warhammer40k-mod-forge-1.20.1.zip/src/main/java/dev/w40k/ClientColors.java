package dev.w40k;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Tints the "main armour" faces (tintindex 0) of every miniature: factory colour or the colour the player painted. */
@Mod.EventBusSubscriber(modid = W40kMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientColors {
    private ClientColors() {}

    static int factoryColor(String id) {
        return id.startsWith("necrons_") ? 0x4A525C : id.startsWith("mechanicus_") ? 0xA82E22 : 0x2F55A4;
    }

    @SubscribeEvent
    public static void onBlockColors(RegisterColorHandlersEvent.Block event) {
        Block[] blocks = ModRegistry.PAINTABLE_BLOCKS.stream().map(RegistryObject::get).toArray(Block[]::new);
        event.register((state, level, pos, tintIndex) -> {
            ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
            int def = factoryColor(key == null ? "" : key.getPath());
            if (tintIndex != 0 || level == null || pos == null) {
                return def;
            }
            BlockPos master = Paint.masterOf(pos, state);
            BlockEntity be = level.getBlockEntity(master);
            if (be instanceof PaintBE p && p.getColor() != 0) {
                return p.getColor();
            }
            return def;
        }, blocks);
    }

    @SubscribeEvent
    public static void onItemColors(RegisterColorHandlersEvent.Item event) {
        Item[] items = ModRegistry.PAINTABLE_ITEMS.stream().map(RegistryObject::get).toArray(Item[]::new);
        event.register((stack, tintIndex) -> {
            ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
            return tintIndex == 0 ? factoryColor(key == null ? "" : key.getPath()) : -1;
        }, items);
    }
}

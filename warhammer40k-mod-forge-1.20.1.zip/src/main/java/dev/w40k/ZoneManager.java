package dev.w40k;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

/** Keeps one range zone per player and draws it as dust particles, one dot per inch, visible only to that player. */
@Mod.EventBusSubscriber(modid = W40kMod.MODID)
public final class ZoneManager {
    private ZoneManager() {}

    public record Ring(double radius, int rgb) {}

    public static final class Zone {
        final String unitId;
        final int kind;
        int mode;
        final ResourceKey<Level> dim;
        final BlockPos master;
        public String unitId() { return unitId; }
        public int kind() { return kind; }
        public int mode() { return mode; }
        public BlockPos master() { return master; }
        long expires;
        final List<double[]> dots = new ArrayList<>(); // x, y, z, rgb
        Zone(String unitId, int kind, int mode, ResourceKey<Level> dim, BlockPos master) {
            this.unitId = unitId;
            this.kind = kind;
            this.mode = mode;
            this.dim = dim;
            this.master = master;
        }
    }

    private static final Map<UUID, Zone> ZONES = new HashMap<>();
    private static final long LIFETIME = 20 * 120;

    public static Zone get(ServerPlayer p) {
        return ZONES.get(p.getUUID());
    }

    public static void clear(ServerPlayer p) {
        ZONES.remove(p.getUUID());
    }

    /** rect = {x0, z0, x1, z1} in world coordinates (block edges). */
    public static void show(ServerPlayer p, ServerLevel level, String unitId, int kind, int mode, BlockPos master, double[] rect, List<Ring> rings) {
        Zone z = new Zone(unitId, kind, mode, level.dimension(), master);
        z.expires = level.getGameTime() + LIFETIME;
        for (Ring r : rings) {
            ringDots(level, z, rect, r, master.getY());
        }
        ZONES.put(p.getUUID(), z);
    }

    private static void ringDots(ServerLevel level, Zone z, double[] rc, Ring r, int y0) {
        double x0 = rc[0], z0 = rc[1], x1 = rc[2], z1 = rc[3], rad = r.radius();
        for (double x = x0; x <= x1 + 1e-6; x += 1.0) {
            dot(level, z, x, z0 - rad, y0, r.rgb());
            dot(level, z, x, z1 + rad, y0, r.rgb());
        }
        for (double zz = z0; zz <= z1 + 1e-6; zz += 1.0) {
            dot(level, z, x0 - rad, zz, y0, r.rgb());
            dot(level, z, x1 + rad, zz, y0, r.rgb());
        }
        int n = Math.max(3, (int) Math.round(Math.PI / 2 * rad / 1.0));
        double[][] centers = {{x0, z0, Math.PI}, {x1, z0, 1.5 * Math.PI}, {x1, z1, 0}, {x0, z1, 0.5 * Math.PI}};
        for (double[] c : centers) {
            for (int i = 1; i < n; i++) {
                double a = c[2] + (Math.PI / 2) * i / n;
                dot(level, z, c[0] + rad * Math.cos(a), c[1] + rad * Math.sin(a), y0, r.rgb());
            }
        }
    }

    private static void dot(ServerLevel level, Zone z, double x, double zz, int y0, int rgb) {
        int bx = Mth.floor(x), bz = Mth.floor(zz);
        if (!level.hasChunkAt(new BlockPos(bx, y0, bz))) {
            return;
        }
        int y = y0;
        for (int i = 0; i < 4 && solid(level, bx, y, bz); i++) {
            y++;
        }
        for (int i = 0; i < 3 && !solid(level, bx, y - 1, bz) && !level.isOutsideBuildHeight(y - 1); i++) {
            y--;
        }
        z.dots.add(new double[]{x, y + 0.15, zz, rgb});
    }

    private static boolean solid(ServerLevel level, int x, int y, int z) {
        BlockPos pos = new BlockPos(x, y, z);
        BlockState st = level.getBlockState(pos);
        return !st.getCollisionShape(level, pos).isEmpty();
    }

    private static boolean isUnit(ServerLevel level, Zone z) {
        ResourceLocation k = ForgeRegistries.BLOCKS.getKey(level.getBlockState(z.master).getBlock());
        return k != null && k.getPath().equals(z.unitId);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ZONES.isEmpty() || event.getServer().getTickCount() % 10 != 0) {
            return;
        }
        Iterator<Map.Entry<UUID, Zone>> it = ZONES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Zone> e = it.next();
            Zone z = e.getValue();
            ServerPlayer p = event.getServer().getPlayerList().getPlayer(e.getKey());
            if (p == null || !(p.level() instanceof ServerLevel level) || !level.dimension().equals(z.dim) || level.getGameTime() > z.expires
                    || !isUnit(level, z)) {
                it.remove();
                continue;
            }
            for (double[] d : z.dots) {
                int rgb = (int) d[3];
                DustParticleOptions opt = new DustParticleOptions(
                        new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f), 1.4F);
                level.sendParticles(p, opt, true, d[0], d[1], d[2], 1, 0, 0, 0, 0);
            }
        }
    }
}

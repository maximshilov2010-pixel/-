package dev.w40k;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Item of a miniature. Single-block models use the normal placement; big ones are placed as a whole footprint. */
public class UnitBlockItem extends BlockItem {
    private final String id;
    private final String faction;
    private final int color;

    public UnitBlockItem(Block block, Properties properties, String id, String faction, int color) {
        super(block, properties);
        this.id = id;
        this.faction = faction;
        this.color = color;
    }

    @Override
    public InteractionResult place(BlockPlaceContext ctx) {
        if (!(getBlock() instanceof BigUnitBlock big)) {
            return super.place(ctx);
        }
        if (!ctx.canPlace()) {
            return InteractionResult.FAIL;
        }
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        BlockPos origin = ctx.getClickedPos();
        Direction facing = ctx.getHorizontalDirection();
        int n = big.w * big.d * big.h;
        for (int i = 0; i < n; i++) {
            BlockPos p = big.tilePos(origin, facing, i);
            if (level.isOutsideBuildHeight(p) || !level.getBlockState(p).canBeReplaced()) {
                if (player != null) {
                    player.displayClientMessage(Component.translatable("msg." + W40kMod.MODID + ".nospace")
                            .withStyle(ChatFormatting.RED), true);
                }
                return InteractionResult.FAIL;
            }
        }
        for (int i = 0; i < n; i++) {
            BlockState st = big.defaultBlockState().setValue(BigUnitBlock.FACING, facing).setValue(big.part, i);
            level.setBlock(big.tilePos(origin, facing, i), st, 3);
        }
        BlockState master = level.getBlockState(origin);
        level.playSound(player, origin, master.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 0.8F);
        ItemStack stack = ctx.getItemInHand();
        if (player == null || !player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("itemGroup." + W40kMod.MODID + ".faction_" + faction).withStyle(Style.EMPTY.withColor(color)));
        String role = "unitrole." + W40kMod.MODID + "." + id;
        if (Language.getInstance().has(role)) {
            tooltip.add(Component.translatable(role).withStyle(ChatFormatting.GRAY));
        }
        String info = "unitinfo." + W40kMod.MODID + "." + id;
        if (Language.getInstance().has(info)) {
            tooltip.add(Component.translatable(info).withStyle(ChatFormatting.YELLOW));
        }
        tooltip.add(Component.translatable("tooltip." + W40kMod.MODID + (getBlock() instanceof BigUnitBlock ? ".big" : ".place"))
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}

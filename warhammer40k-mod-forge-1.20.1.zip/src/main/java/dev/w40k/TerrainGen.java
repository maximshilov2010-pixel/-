package dev.w40k;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Builds a battlefield: flat floor plus ready-made terrain features, 1 block = 1 inch. */
public final class TerrainGen {
    public enum Type {
        FLAT("flat"), CITY("city"), RUINS("ruins"), WASTELAND("wasteland"), FOREST("forest"), TOMB("tomb"), DESERT("desert");
        public final String id;

        Type(String id) {
            this.id = id;
        }
    }

    private final ServerLevel level;
    private final int ox, oz, floorY, width, depth;
    private final Type type;
    private final Random rnd = new Random();
    private final List<int[]> used = new ArrayList<>();

    // palette
    private Block[] floor;
    private Block[] wall;
    private Block[] rubble;
    private Block hillTop, hillBody, barricade, accent;

    public TerrainGen(ServerLevel level, BlockPos origin, int floorY, int width, int depth, Type type) {
        this.level = level;
        this.ox = origin.getX();
        this.oz = origin.getZ();
        this.floorY = floorY;
        this.width = width;
        this.depth = depth;
        this.type = type;
        palette();
    }

    private void palette() {
        switch (type) {
            case CITY -> {
                floor = new Block[]{Blocks.GRAY_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE};
                wall = new Block[]{Blocks.STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.GRAY_CONCRETE, Blocks.CRACKED_STONE_BRICKS};
                rubble = new Block[]{Blocks.COBBLESTONE, Blocks.GRAVEL, Blocks.ANDESITE};
                hillTop = Blocks.ANDESITE; hillBody = Blocks.STONE; barricade = Blocks.SMOOTH_STONE; accent = Blocks.IRON_BLOCK;
            }
            case RUINS -> {
                floor = new Block[]{Blocks.STONE, Blocks.COBBLESTONE, Blocks.GRAVEL, Blocks.ANDESITE, Blocks.STONE};
                wall = new Block[]{Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.MOSSY_COBBLESTONE};
                rubble = new Block[]{Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE, Blocks.GRAVEL};
                hillTop = Blocks.COBBLESTONE; hillBody = Blocks.STONE; barricade = Blocks.COBBLESTONE; accent = Blocks.MOSSY_COBBLESTONE;
            }
            case WASTELAND -> {
                floor = new Block[]{Blocks.COARSE_DIRT, Blocks.COARSE_DIRT, Blocks.RED_SAND, Blocks.GRAVEL, Blocks.TERRACOTTA};
                wall = new Block[]{Blocks.TERRACOTTA, Blocks.BROWN_TERRACOTTA, Blocks.CRACKED_STONE_BRICKS};
                rubble = new Block[]{Blocks.COARSE_DIRT, Blocks.GRAVEL, Blocks.RED_SAND};
                hillTop = Blocks.TERRACOTTA; hillBody = Blocks.RED_TERRACOTTA; barricade = Blocks.IRON_BLOCK; accent = Blocks.RAW_IRON_BLOCK;
            }
            case FOREST -> {
                floor = new Block[]{Blocks.GRASS_BLOCK, Blocks.GRASS_BLOCK, Blocks.GRASS_BLOCK, Blocks.PODZOL, Blocks.COARSE_DIRT};
                wall = new Block[]{Blocks.MOSSY_STONE_BRICKS, Blocks.MOSSY_COBBLESTONE, Blocks.STONE_BRICKS};
                rubble = new Block[]{Blocks.MOSSY_COBBLESTONE, Blocks.COBBLESTONE};
                hillTop = Blocks.GRASS_BLOCK; hillBody = Blocks.DIRT; barricade = Blocks.MOSSY_COBBLESTONE; accent = Blocks.MOSS_BLOCK;
            }
            case TOMB -> {
                floor = new Block[]{Blocks.DEEPSLATE_TILES, Blocks.DEEPSLATE, Blocks.POLISHED_DEEPSLATE, Blocks.DEEPSLATE_TILES};
                wall = new Block[]{Blocks.DEEPSLATE_BRICKS, Blocks.CRACKED_DEEPSLATE_BRICKS, Blocks.POLISHED_BLACKSTONE_BRICKS};
                rubble = new Block[]{Blocks.DEEPSLATE, Blocks.COBBLED_DEEPSLATE, Blocks.BLACKSTONE};
                hillTop = Blocks.BLACKSTONE; hillBody = Blocks.DEEPSLATE; barricade = Blocks.POLISHED_BLACKSTONE; accent = Blocks.VERDANT_FROGLIGHT;
            }
            case DESERT -> {
                floor = new Block[]{Blocks.SAND, Blocks.SAND, Blocks.SAND, Blocks.SANDSTONE};
                wall = new Block[]{Blocks.SANDSTONE, Blocks.CUT_SANDSTONE, Blocks.SMOOTH_SANDSTONE};
                rubble = new Block[]{Blocks.SAND, Blocks.SANDSTONE};
                hillTop = Blocks.SAND; hillBody = Blocks.SANDSTONE; barricade = Blocks.SANDSTONE; accent = Blocks.CHISELED_SANDSTONE;
            }
            default -> {
                floor = new Block[]{Blocks.GRAY_CONCRETE};
                wall = new Block[]{Blocks.STONE_BRICKS};
                rubble = new Block[]{Blocks.COBBLESTONE};
                hillTop = Blocks.STONE; hillBody = Blocks.STONE; barricade = Blocks.STONE; accent = Blocks.STONE;
            }
        }
    }

    private <T> T pick(T[] a) {
        return a[rnd.nextInt(a.length)];
    }

    private void set(int x, int y, int z, Block b) {
        level.setBlock(new BlockPos(ox + x, floorY + y, oz + z), b.defaultBlockState(), 2);
    }

    private void setState(int x, int y, int z, BlockState s) {
        level.setBlock(new BlockPos(ox + x, floorY + y, oz + z), s, 2);
    }

    public void build() {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState edge = Blocks.WHITE_CONCRETE.defaultBlockState();
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                boolean border = x == 0 || z == 0 || x == width - 1 || z == depth - 1;
                boolean grid = (x % 6 == 0 || z % 6 == 0);
                BlockState f;
                if (border) {
                    f = edge;
                } else if (type == Type.FLAT) {
                    f = grid ? Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState() : Blocks.GRAY_CONCRETE.defaultBlockState();
                } else {
                    f = pick(floor).defaultBlockState();
                }
                level.setBlock(new BlockPos(ox + x, floorY, oz + z), f, 2);
                for (int h = 1; h <= 12; h++) {
                    level.setBlock(new BlockPos(ox + x, floorY + h, oz + z), air, 2);
                }
            }
        }
        if (type == Type.FLAT) {
            return;
        }
        int features = Math.max(3, width * depth / 200);
        for (int i = 0; i < features; i++) {
            for (int attempt = 0; attempt < 25; attempt++) {
                if (place(pickFeature())) {
                    break;
                }
            }
        }
    }

    private int pickFeature() {
        int r = rnd.nextInt(100);
        return switch (type) {
            case CITY -> r < 45 ? 0 : r < 70 ? 1 : r < 90 ? 2 : 3;      // ruin, barricade, container, crater
            case RUINS -> r < 40 ? 0 : r < 60 ? 4 : r < 80 ? 1 : 3;     // ruin, rubble hill, barricade, crater
            case WASTELAND -> r < 30 ? 4 : r < 55 ? 3 : r < 75 ? 0 : r < 90 ? 1 : 5; // hill, crater, ruin, barricade, dead tree
            case FOREST -> r < 55 ? 6 : r < 75 ? 4 : r < 90 ? 0 : 1;   // wood, hill, ruin, barricade
            case TOMB -> r < 35 ? 0 : r < 60 ? 7 : r < 80 ? 8 : 4;      // ruin, pillar, sarcophagus, hill
            default -> r < 55 ? 9 : r < 80 ? 4 : r < 95 ? 0 : 3;        // dune, mesa, ruin, crater
        };
    }

    /** Footprints must not overlap and must stay out of the deployment strips at both short ends. */
    private boolean reserve(int x, int z, int w, int d) {
        int zone = Math.min(9, depth / 5);
        if (x < 2 || z < zone || x + w > width - 2 || z + d > depth - zone) {
            return false;
        }
        for (int[] u : used) {
            if (x < u[0] + u[2] + 1 && x + w + 1 > u[0] && z < u[1] + u[3] + 1 && z + d + 1 > u[1]) {
                return false;
            }
        }
        used.add(new int[]{x, z, w, d});
        return true;
    }

    private int rx(int w) {
        return 2 + rnd.nextInt(Math.max(1, width - w - 3));
    }

    private int rz(int d) {
        int zone = Math.min(9, depth / 5);
        return zone + rnd.nextInt(Math.max(1, depth - 2 * zone - d + 1));
    }

    private boolean place(int kind) {
        switch (kind) {
            case 0: return ruin();
            case 1: return barricadeLine();
            case 2: return container();
            case 3: return crater();
            case 4: return hill(2 + rnd.nextInt(2), 3 + rnd.nextInt(3), 3 + rnd.nextInt(3), hillTop, hillBody);
            case 5: return deadTree();
            case 6: return wood();
            case 7: return pillar();
            case 8: return sarcophagus();
            default: return dune();
        }
    }

    private boolean ruin() {
        boolean tall = type == Type.CITY;
        int w = 6 + rnd.nextInt(5), d = 5 + rnd.nextInt(4);
        int h = tall ? 5 + rnd.nextInt(4) : 3 + rnd.nextInt(3);
        int x = rx(w), z = rz(d);
        if (!reserve(x, z, w, d)) {
            return false;
        }
        boolean decay = type != Type.CITY;
        int[] doorN = {1 + rnd.nextInt(w - 3)}, doorS = {1 + rnd.nextInt(w - 3)};
        int doorE = 1 + rnd.nextInt(d - 3), doorW = 1 + rnd.nextInt(d - 3);
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < d; j++) {
                boolean per = i == 0 || j == 0 || i == w - 1 || j == d - 1;
                if (!per) {
                    if (rnd.nextInt(6) == 0) {
                        set(x + i, 1, z + j, pick(rubble));
                    }
                    continue;
                }
                boolean corner = (i == 0 || i == w - 1) && (j == 0 || j == d - 1);
                boolean door = (j == 0 && (i == doorN[0] || i == doorN[0] + 1)) || (j == d - 1 && (i == doorS[0] || i == doorS[0] + 1))
                        || (i == 0 && (j == doorE || j == doorE + 1)) || (i == w - 1 && (j == doorW || j == doorW + 1));
                int hh = corner ? h : (decay ? Math.max(1, h - rnd.nextInt(4)) : h);
                for (int y = 1; y <= hh; y++) {
                    if (door && y <= 3) {
                        continue;
                    }
                    boolean window = !corner && y >= 2 && y <= 3 && ((i + j) % 3 == 0) && !door && hh >= 4;
                    if (window) {
                        continue;
                    }
                    set(x + i, y, z + j, pick(wall));
                }
            }
        }
        if (type == Type.TOMB) {
            set(x, h + 1, z, accent);
            set(x + w - 1, h + 1, z + d - 1, accent);
        }
        return true;
    }

    private boolean barricadeLine() {
        boolean alongX = rnd.nextBoolean();
        int len = 4 + rnd.nextInt(5);
        int w = alongX ? len : 1, d = alongX ? 1 : len;
        int x = rx(w), z = rz(d);
        if (!reserve(x, z, w, d)) {
            return false;
        }
        for (int i = 0; i < len; i++) {
            if (rnd.nextInt(7) == 0) {
                continue;
            }
            set(x + (alongX ? i : 0), 1, z + (alongX ? 0 : i), barricade);
        }
        return true;
    }

    private boolean container() {
        Block[] col = {Blocks.RED_TERRACOTTA, Blocks.BLUE_TERRACOTTA, Blocks.YELLOW_TERRACOTTA, Blocks.GRAY_TERRACOTTA, Blocks.GREEN_TERRACOTTA};
        boolean alongX = rnd.nextBoolean();
        int w = alongX ? 4 : 2, d = alongX ? 2 : 4;
        int x = rx(w), z = rz(d);
        if (!reserve(x, z, w, d)) {
            return false;
        }
        Block b = pick(col);
        int stack = 1 + rnd.nextInt(2);
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < d; j++) {
                for (int y = 1; y <= stack + 1; y++) {
                    set(x + i, y, z + j, y == 1 || rnd.nextBoolean() ? b : pick(col));
                }
            }
        }
        return true;
    }

    private boolean crater() {
        int r = 2 + rnd.nextInt(3);
        int x = rx(2 * r + 1), z = rz(2 * r + 1);
        if (!reserve(x, z, 2 * r + 1, 2 * r + 1)) {
            return false;
        }
        for (int i = -r; i <= r; i++) {
            for (int j = -r; j <= r; j++) {
                double dist = Math.sqrt(i * i + j * j);
                if (dist > r) {
                    continue;
                }
                if (dist >= r - 1.0) {
                    set(x + r + i, 1, z + r + j, pick(rubble));
                } else {
                    set(x + r + i, 0, z + r + j, type == Type.TOMB ? Blocks.BLACKSTONE : Blocks.COARSE_DIRT);
                }
            }
        }
        return true;
    }

    private boolean hill(int hmax, int rxr, int rzr, Block top, Block body) {
        int w = 2 * rxr + 1, d = 2 * rzr + 1;
        int x = rx(w), z = rz(d);
        if (!reserve(x, z, w, d)) {
            return false;
        }
        for (int i = -rxr; i <= rxr; i++) {
            for (int j = -rzr; j <= rzr; j++) {
                double dd = Math.sqrt((double) i * i / (rxr * rxr) + (double) j * j / (rzr * rzr));
                if (dd >= 1.0) {
                    continue;
                }
                int hh = Math.max(1, (int) Math.ceil(hmax * (1.0 - dd)));
                for (int y = 1; y <= hh; y++) {
                    set(x + rxr + i, y, z + rzr + j, y == hh ? top : body);
                }
            }
        }
        return true;
    }

    private boolean dune() {
        if (rnd.nextInt(3) == 0) {
            return hill(3 + rnd.nextInt(2), 3 + rnd.nextInt(2), 3 + rnd.nextInt(2), Blocks.SANDSTONE, Blocks.SANDSTONE);
        }
        return hill(2 + rnd.nextInt(2), 5 + rnd.nextInt(4), 3 + rnd.nextInt(3), Blocks.SAND, Blocks.SAND);
    }

    private boolean deadTree() {
        int x = rx(1), z = rz(1);
        if (!reserve(x, z, 1, 1)) {
            return false;
        }
        int h = 3 + rnd.nextInt(3);
        for (int y = 1; y <= h; y++) {
            set(x, y, z, Blocks.DARK_OAK_LOG);
        }
        return true;
    }

    private void tree(int x, int z) {
        int h = 4 + rnd.nextInt(2);
        for (int y = 1; y <= h; y++) {
            set(x, y, z, Blocks.OAK_LOG);
        }
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        for (int dy = h - 2; dy <= h + 1; dy++) {
            int r = dy >= h ? 1 : 2;
            for (int i = -r; i <= r; i++) {
                for (int j = -r; j <= r; j++) {
                    if (Math.abs(i) == r && Math.abs(j) == r && rnd.nextBoolean()) {
                        continue;
                    }
                    int px = x + i, pz = z + j;
                    if (px < 1 || pz < 1 || px > width - 2 || pz > depth - 2) {
                        continue;
                    }
                    if (level.getBlockState(new BlockPos(ox + px, floorY + dy, oz + pz)).isAir()) {
                        setState(px, dy, pz, leaves);
                    }
                }
            }
        }
    }

    private boolean wood() {
        int r = 4 + rnd.nextInt(3);
        int x = rx(2 * r + 1), z = rz(2 * r + 1);
        if (!reserve(x, z, 2 * r + 1, 2 * r + 1)) {
            return false;
        }
        for (int i = 1; i < 2 * r; i += 3) {
            for (int j = 1; j < 2 * r; j += 3) {
                double dist = Math.hypot(i - r, j - r);
                if (dist <= r && rnd.nextInt(10) < 7) {
                    tree(x + i, z + j);
                }
            }
        }
        return true;
    }

    private boolean pillar() {
        int x = rx(1), z = rz(1);
        if (!reserve(x, z, 1, 1)) {
            return false;
        }
        int h = 4 + rnd.nextInt(3);
        for (int y = 1; y <= h; y++) {
            set(x, y, z, y == 1 || y == h ? Blocks.POLISHED_DEEPSLATE : Blocks.DEEPSLATE_BRICKS);
        }
        set(x, h + 1, z, accent);
        return true;
    }

    private boolean sarcophagus() {
        boolean alongX = rnd.nextBoolean();
        int w = alongX ? 4 : 2, d = alongX ? 2 : 4;
        int x = rx(w), z = rz(d);
        if (!reserve(x, z, w, d)) {
            return false;
        }
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < d; j++) {
                set(x + i, 1, z + j, Blocks.POLISHED_BLACKSTONE_BRICKS);
                set(x + i, 2, z + j, (i + j) % 2 == 0 ? Blocks.POLISHED_BLACKSTONE : Blocks.POLISHED_BLACKSTONE_BRICKS);
            }
        }
        set(x + w / 2, 3, z + d / 2, accent);
        return true;
    }
}

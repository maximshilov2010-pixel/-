package dev.w40k;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = W40kMod.MODID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    public static final RegistryObject<Item> D6 =
            ITEMS.register("d6", () -> new D6DiceItem(new Item.Properties().stacksTo(64)));
    public static final RegistryObject<Item> RULER =
            ITEMS.register("ruler", () -> new RulerItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> MOVE_TOOL =
            ITEMS.register("move_tool", () -> new RangeToolItem(new Item.Properties().stacksTo(1), RangeToolItem.MOVE));
    public static final RegistryObject<Item> ATTACK_TOOL =
            ITEMS.register("attack_tool", () -> new RangeToolItem(new Item.Properties().stacksTo(1), RangeToolItem.ATTACK));

    private static final Map<String, List<RegistryObject<Item>>> FACTION_ITEMS = new LinkedHashMap<>();
    private static final List<RegistryObject<Item>> MARKER_ITEMS = new ArrayList<>();
    private static final String[] RULE_BOOKS = {"rules_basics", "rules_turn", "rules_attack", "rules_keywords", "rules_strats", "rules_tools"};

    private static BlockBehaviour.Properties tokenProps() {
        return BlockBehaviour.Properties.of().instabreak().noOcclusion().sound(SoundType.METAL);
    }

    private static RegistryObject<Item> registerSmall(String id, String faction, int color) {
        RegistryObject<Block> block = BLOCKS.register(id, () -> new UnitTokenBlock(tokenProps()));
        return ITEMS.register(id, () -> new UnitBlockItem(block.get(), new Item.Properties(), id, faction, color));
    }

    private static RegistryObject<Item> registerBig(String id, String faction, int color, int w, int d, int h) {
        RegistryObject<Block> block = BLOCKS.register(id, () -> new BigUnitBlock(tokenProps(), w, d, h));
        return ITEMS.register(id, () -> new UnitBlockItem(block.get(), new Item.Properties(), id, faction, color));
    }

    static {
        for (UnitData.Faction f : UnitData.FACTIONS) {
            FACTION_ITEMS.put(f.id(), new ArrayList<>());
        }
        for (UnitData.Unit u : UnitData.UNITS) {
            int color = 0xFFFFFF;
            for (UnitData.Faction f : UnitData.FACTIONS) {
                if (f.id().equals(u.faction())) {
                    color = f.color();
                }
            }
            RegistryObject<Item> item = (u.w() * u.d() * u.h() == 1)
                    ? registerSmall(u.id(), u.faction(), color)
                    : registerBig(u.id(), u.faction(), color, u.w(), u.d(), u.h());
            FACTION_ITEMS.get(u.faction()).add(item);
        }
        for (String m : UnitData.MARKERS) {
            MARKER_ITEMS.add(registerSmall(m, "neutral", 0x8A8F98));
        }

        for (UnitData.Faction f : UnitData.FACTIONS) {
            final String fid = f.id();
            TABS.register("faction_" + fid, () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + ID + ".faction_" + fid))
                    .icon(() -> new ItemStack(FACTION_ITEMS.get(fid).get(0).get()))
                    .displayItems((params, out) -> {
                        for (String book : UnitData.BOOKS.getOrDefault(fid, List.of())) {
                            out.accept(GuideBooks.create(book));
                        }
                        for (RegistryObject<Item> it : FACTION_ITEMS.get(fid)) {
                            out.accept(it.get());
                        }
                    })
                    .build());
        }

        TABS.register("rules", () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup." + ID + ".rules"))
                .icon(() -> new ItemStack(D6.get()))
                .displayItems((params, out) -> {
                    for (String book : RULE_BOOKS) {
                        out.accept(GuideBooks.create(book));
                    }
                    out.accept(RULER.get());
                    out.accept(MOVE_TOOL.get());
                    out.accept(ATTACK_TOOL.get());
                    out.accept(D6.get());
                    for (RegistryObject<Item> it : MARKER_ITEMS) {
                        out.accept(it.get());
                    }
                })
                .build());
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}

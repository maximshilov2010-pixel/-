package dev.w40k;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = W40kMod.MODID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    public static final RegistryObject<Item> D6 =
            ITEMS.register("d6", () -> new D6DiceItem(new Item.Properties().stacksTo(64)));
    public static final RegistryObject<Item> RULER =
            ITEMS.register("ruler", () -> new RulerItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> MOVE_TOOL =
            ITEMS.register("move_tool", () -> new RangeToolItem(new Item.Properties().stacksTo(1), RangeToolItem.MOVE));
    public static final RegistryObject<Item> ATTACK_TOOL =
            ITEMS.register("attack_tool", () -> new RangeToolItem(new Item.Properties().stacksTo(1), RangeToolItem.ATTACK));

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ID);
    public static final List<RegistryObject<Block>> PAINTABLE_BLOCKS = new ArrayList<>();
    public static final List<RegistryObject<Item>> PAINTABLE_ITEMS = new ArrayList<>();
    public static final RegistryObject<BlockEntityType<PaintBE>> PAINT_BE = BLOCK_ENTITIES.register("paint",
            () -> BlockEntityType.Builder.of(PaintBE::new, PAINTABLE_BLOCKS.stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    public static final RegistryObject<Item> PAINT_REMOVER = ITEMS.register("paint_remover", () -> new Item(new Item.Properties().stacksTo(1)) {
        @Override
        public InteractionResult useOn(UseOnContext context) {
            Level level = context.getLevel();
            BlockState state = level.getBlockState(context.getClickedPos());
            if (!(state.getBlock() instanceof UnitTokenBlock) && !(state.getBlock() instanceof BigUnitBlock)) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide) {
                Paint.apply(level, context.getClickedPos(), state, 0);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
            tooltip.add(Component.translatable("tooltip." + ID + ".paint_remover.1").withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("tooltip." + ID + ".paint_remover.2").withStyle(ChatFormatting.GRAY));
        }
    });

    private static final Map<String, List<RegistryObject<Item>>> FACTION_ITEMS = new LinkedHashMap<>();
    private static final List<RegistryObject<Item>> MARKER_ITEMS = new ArrayList<>();
    private static final String[] RULE_BOOKS = {"rules_basics", "rules_turn", "rules_attack", "rules_keywords", "rules_strats", "rules_tools"};

    private static BlockBehaviour.Properties tokenProps() {
        return BlockBehaviour.Properties.of().instabreak().noOcclusion().sound(SoundType.METAL);
    }

    private static RegistryObject<Item> registerSmall(String id, String faction, int color) {
        boolean paintable = !faction.equals("neutral");
        RegistryObject<Block> block = BLOCKS.register(id, () -> new UnitTokenBlock(tokenProps(), paintable));
        RegistryObject<Item> item = ITEMS.register(id, () -> new UnitBlockItem(block.get(), new Item.Properties(), id, faction, color));
        if (paintable) {
            PAINTABLE_BLOCKS.add(block);
            PAINTABLE_ITEMS.add(item);
        }
        return item;
    }

    private static RegistryObject<Item> registerBig(String id, String faction, int color, int w, int d, int h) {
        RegistryObject<Block> block = BLOCKS.register(id, () -> new BigUnitBlock(tokenProps(), w, d, h));
        RegistryObject<Item> item = ITEMS.register(id, () -> new UnitBlockItem(block.get(), new Item.Properties(), id, faction, color));
        PAINTABLE_BLOCKS.add(block);
        PAINTABLE_ITEMS.add(item);
        return item;
    }

    static {
        for (UnitData.Faction f : UnitData.FACTIONS) {
            FACTION_ITEMS.put(f.id(), new ArrayList<>());
        }
        for (UnitData.Unit u : UnitData.UNITS) {
            int color = 0xFFFFFF;
            for (UnitData.Faction f : UnitData.FACTIONS) {
                if (f.id().equals(u.faction())) {
                    color = f.color();
                }
            }
            RegistryObject<Item> item = (u.w() * u.d() * u.h() == 1)
                    ? registerSmall(u.id(), u.faction(), color)
                    : registerBig(u.id(), u.faction(), color, u.w(), u.d(), u.h());
            FACTION_ITEMS.get(u.faction()).add(item);
        }
        for (String m : UnitData.MARKERS) {
            MARKER_ITEMS.add(registerSmall(m, "neutral", 0x8A8F98));
        }

        for (UnitData.Faction f : UnitData.FACTIONS) {
            final String fid = f.id();
            TABS.register("faction_" + fid, () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + ID + ".faction_" + fid))
                    .icon(() -> new ItemStack(FACTION_ITEMS.get(fid).get(0).get()))
                    .displayItems((params, out) -> {
                        for (String book : UnitData.BOOKS.getOrDefault(fid, List.of())) {
                            out.accept(GuideBooks.create(book));
                        }
                        for (RegistryObject<Item> it : FACTION_ITEMS.get(fid)) {
                            out.accept(it.get());
                        }
                    })
                    .build());
        }

        TABS.register("rules", () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup." + ID + ".rules"))
                .icon(() -> new ItemStack(D6.get()))
                .displayItems((params, out) -> {
                    for (String book : RULE_BOOKS) {
                        out.accept(GuideBooks.create(book));
                    }
                    out.accept(RULER.get());
                    out.accept(MOVE_TOOL.get());
                    out.accept(ATTACK_TOOL.get());
                    out.accept(PAINT_REMOVER.get());
                    out.accept(D6.get());
                    for (RegistryObject<Item> it : MARKER_ITEMS) {
                        out.accept(it.get());
                    }
                })
                .build());
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        BLOCK_ENTITIES.register(bus);
    }
}

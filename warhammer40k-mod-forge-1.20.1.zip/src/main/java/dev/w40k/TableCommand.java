package dev.w40k;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /w40ktable [type] [width depth] - types: flat city ruins wasteland forest tomb desert. Flat battlefield under your feet; default 44 x 60 blocks = 44" x 60" (standard Strike Force table). */
@Mod.EventBusSubscriber(modid = W40kMod.MODID)
public final class TableCommand {
    private TableCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        var root = Commands.literal("w40ktable").requires(src -> src.hasPermission(2))
                .executes(ctx -> build(ctx.getSource(), 44, 60, TerrainGen.Type.FLAT))
                .then(Commands.argument("width", IntegerArgumentType.integer(8, 120))
                        .then(Commands.argument("depth", IntegerArgumentType.integer(8, 120))
                                .executes(ctx -> build(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "width"),
                                        IntegerArgumentType.getInteger(ctx, "depth"), TerrainGen.Type.FLAT))));
        for (TerrainGen.Type t : TerrainGen.Type.values()) {
            root.then(Commands.literal(t.id)
                    .executes(ctx -> build(ctx.getSource(), 44, 60, t))
                    .then(Commands.argument("width", IntegerArgumentType.integer(8, 120))
                            .then(Commands.argument("depth", IntegerArgumentType.integer(8, 120))
                                    .executes(ctx -> build(ctx.getSource(),
                                            IntegerArgumentType.getInteger(ctx, "width"),
                                            IntegerArgumentType.getInteger(ctx, "depth"), t)))));
        }
        event.getDispatcher().register(root);
    }

    private static int build(CommandSourceStack src, int width, int depth, TerrainGen.Type type) {
        ServerLevel level = src.getLevel();
        Vec3 v = src.getPosition();
        BlockPos origin = BlockPos.containing(v.x, v.y, v.z);
        new TerrainGen(level, origin, origin.getY() - 1, width, depth, type).build();
        src.sendSuccess(() -> Component.translatable("msg." + W40kMod.MODID + ".table.done", width, depth), true);
        return 1;
    }
}

package dev.w40k;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Stores the paint colour (RGB, 0 = factory colour) of a miniature. Big models keep it in their master (part 0) block only. */
public class PaintBE extends BlockEntity {
    private int color = 0;

    public PaintBE(BlockPos pos, BlockState state) {
        super(ModRegistry.PAINT_BE.get(), pos, state);
    }

    public int getColor() {
        return color;
    }

    public void setColor(int rgb) {
        this.color = rgb;
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("paint", color);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        color = tag.getInt("paint");
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /** Forge calls load() (not handleUpdateTag) for block-entity packets, so re-mesh here to show the new colour. */
    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        super.onDataPacket(net, pkt);
        if (level != null && level.isClientSide) {
            Paint.refresh(level, worldPosition);
        }
    }

    @Override
    public void handleUpdateTag(CompoundTag tag) {
        super.handleUpdateTag(tag);
        if (level != null && level.isClientSide) {
            Paint.refresh(level, worldPosition);
        }
    }
}

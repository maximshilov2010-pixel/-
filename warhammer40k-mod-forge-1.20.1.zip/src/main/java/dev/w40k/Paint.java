package dev.w40k;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public final class Paint {
    private Paint() {}

    public static BlockPos masterOf(BlockPos pos, BlockState state) {
        return state.getBlock() instanceof BigUnitBlock big ? big.masterOf(pos, state) : pos;
    }

    /** Server side: paint the whole miniature that contains pos. rgb = 0 removes the paint. */
    public static boolean apply(Level level, BlockPos pos, BlockState state, int rgb) {
        if (level.getBlockEntity(masterOf(pos, state)) instanceof PaintBE be) {
            be.setColor(rgb);
            return true;
        }
        return false;
    }

    /** Client side: re-mesh every block of the miniature so the new tint shows up. */
    public static void refresh(Level level, BlockPos master) {
        BlockState st = level.getBlockState(master);
        if (st.getBlock() instanceof BigUnitBlock big) {
            int n = big.w * big.d * big.h;
            for (int i = 0; i < n; i++) {
                BlockPos p = big.tilePos(master, st.getValue(BigUnitBlock.FACING), i);
                BlockState s = level.getBlockState(p);
                level.sendBlockUpdated(p, s, s, 8);
            }
        } else {
            level.sendBlockUpdated(master, st, st, 8);
        }
    }
}
